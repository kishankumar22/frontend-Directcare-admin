"use strict";exports.id=251,exports.ids=[251],exports.modules={35222:(a,b,c)=>{c.d(b,{Ay:()=>f,JR:()=>d,Sn:()=>e});let d="https://testapi.knowledgemarkg.com",e={login:`${d}/api/auth/login`,register:`${d}/api/auth/register`,categories:`${d}/api/categories`,brands:`${d}/api/brands`,manufacturers:`${d}/api/manufacturers`,products:`${d}/api/products`,orders:`${d}/api/orders`,customers:`${d}/api/customers`,banners:`${d}/api/banners`,uploadImage:`${d}/api/upload-image`},f=d},90446:(a,b,c)=>{c.d(b,{B:()=>g});var d=c(21124),e=c(38301);let f=({value:a,onChange:b,placeholder:c="Start typing...",height:f=400,className:g=""})=>{let h=(0,e.useRef)(null),i=(0,e.useRef)(b),j=(0,e.useRef)(!1),[k,l]=(0,e.useState)(!1),[m,n]=(0,e.useState)(!1),[o,p]=(0,e.useState)(!1),[q]=(0,e.useState)(()=>`tinymce-${Date.now()}-${Math.random().toString(36).substr(2,9)}`);(0,e.useEffect)(()=>{i.current=b},[b]),(0,e.useEffect)(()=>{n(!0)},[]);let r=async a=>{try{let b=a.split("/"),c=b[b.length-1];if(!c)return console.error("Could not extract filename from URL:",a),!1;let d=await fetch(`https://testapi.knowledgemarkg.com/api/Editor/delete-image?fileName=${c}`,{method:"DELETE",headers:{Authorization:`Bearer ${localStorage.getItem("authToken")}`,"Content-Type":"application/json"}});if(!d.ok)return console.error("Failed to delete image:",d.statusText),!1;return console.log("✅ Image deleted successfully:",c),!0}catch(a){return console.error("❌ Error deleting image:",a),!1}};return((0,e.useEffect)(()=>{if(!m)return;let b=()=>{window.tinymce&&window.tinymce.init({selector:`#${q}`,height:f,license_key:"gpl",base_url:"/tinymce",suffix:".min",plugins:["advlist","autolink","lists","link","image","charmap","searchreplace","visualblocks","code","fullscreen","insertdatetime","media","table","wordcount","help"],toolbar:"undo redo | formatselect | bold italic underline | alignleft aligncenter alignright | bullist numlist | link image | deleteimage | removeformat | code",skin:"oxide-dark",content_css:"dark",menubar:"edit view insert format tools",content_style:`
          body { 
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            font-size: 14px; 
            line-height: 1.6;
            color: #f1f5f9 !important;
            background-color: #0f172a !important;
            margin: 0;
            padding: 16px;
            min-height: ${f-120}px;
            box-sizing: border-box;
          }
          
          body:empty::before {
            content: "${c}";
            color: #ffffff;
            opacity: 0.6;
          }
          
          * {
            color: #f1f5f9 !important;
          }
          
          p {
            margin: 0 0 1em 0;
            line-height: 1.6;
            color: #e2e8f0 !important;
            min-height: 1.4em;
          }
          
          p:first-child {
            margin-top: 0;
          }
          
          p:last-child {
            margin-bottom: 0;
          }
          
          p:empty {
            min-height: 1.4em;
          }
          
          h1, h2, h3, h4, h5, h6 { 
            color: #f8fafc !important; 
            margin: 1.2em 0 0.6em 0; 
            font-weight: 600;
            line-height: 1.4;
          }
          
          strong, b {
            color: #f8fafc !important;
            font-weight: 600;
          }
          
          em, i {
            color: #e2e8f0 !important;
            font-style: italic;
          }
          
          u {
            color: #e2e8f0 !important;
            text-decoration: underline;
          }
          
          a { 
            color: #a855f7 !important; 
            text-decoration: underline;
          }
          
          a:hover {
            color: #c084fc !important;
          }
          
          ul, ol {
            color: #e2e8f0 !important;
            padding-left: 1.5em;
            margin: 0.8em 0;
          }
          
          li {
            color: #e2e8f0 !important;
            margin: 0.4em 0;
            line-height: 1.6;
          }
          
          table { 
            border-collapse: collapse; 
            width: 100%; 
            margin: 1em 0; 
            background-color: #1e293b !important;
            border: 1px solid #475569;
          }
          
          th, td { 
            border: 1px solid #475569; 
            padding: 8px 12px; 
            text-align: left; 
            color: #e2e8f0 !important;
          }
          
          th { 
            background-color: #334155 !important; 
            font-weight: 600;
            color: #f1f5f9 !important;
          }
          
          tr:nth-child(even) td {
            background-color: #334155 !important;
          }
          
          code { 
            background-color: #374151 !important; 
            color: #fbbf24 !important; 
            padding: 2px 6px; 
            border-radius: 4px;
            font-family: 'SF Mono', Monaco, Consolas, monospace;
          }
          
          pre {
            background-color: #111827 !important;
            color: #f3f4f6 !important;
            padding: 16px;
            border-radius: 8px;
            overflow-x: auto;
            border: 1px solid #374151;
          }
          
          blockquote {
            border-left: 4px solid #8b5cf6;
            margin: 1em 0;
            padding: 0.5em 1em;
            color: #cbd5e1 !important;
            background-color: #334155 !important;
            border-radius: 0 8px 8px 0;
          }
          
          hr {
            border: none;
            border-top: 2px solid #475569;
            margin: 1.5em 0;
          }
          
          img {
            max-width: 100%;
            height: auto;
            border-radius: 8px;
            cursor: pointer;
          }
          
          img:hover {
            opacity: 0.8;
            box-shadow: 0 0 0 2px #a855f7;
          }
          
          img[data-mce-selected] {
            box-shadow: 0 0 0 3px #a855f7 !important;
          }
        `,branding:!1,promotion:!1,resize:!0,toolbar_mode:"wrap",statusbar:!0,elementpath:!1,images_upload_handler:async(a,b)=>new Promise(async(b,c)=>{try{let d,e=new FormData;e.append("file",a.blob(),a.filename());let f="https://testapi.knowledgemarkg.com",g=await fetch(`${f}/api/Editor/upload-image`,{method:"POST",headers:{Authorization:`Bearer ${localStorage.getItem("authToken")}`},body:e});if(!g.ok)return void c(`❌ Upload failed: ${g.statusText}`);try{d=await g.json()}catch(a){c("❌ Upload failed: Invalid JSON response");return}d?.location?b(`${f}${d.location}`):c("❌ Upload failed: Missing image location")}catch(a){console.error("Upload error:",a),c("❌ Upload failed: Network error")}}),file_picker_types:"image",file_picker_callback:(a,b,c)=>{if("image"===c.filetype){let b=document.createElement("input");b.setAttribute("type","file"),b.setAttribute("accept","image/png,image/jpeg,image/gif,image/webp"),b.style.display="none",document.body.appendChild(b),b.onchange=async function(){let c=this.files?.[0];if(document.body.removeChild(b),c)try{h.current&&h.current.notificationManager.open({text:"⏳ Uploading image...",type:"info",timeout:3e3});let b=new FormData;b.append("file",c,c.name);let d="https://testapi.knowledgemarkg.com",e=await fetch(`${d}/api/Editor/upload-image`,{method:"POST",headers:{Authorization:`Bearer ${localStorage.getItem("authToken")}`},body:b});if(!e.ok)throw Error(`Upload failed: ${e.statusText}`);let f=await e.json();if(f?.location){let b=`${d}${f.location}`;a(b,{alt:c.name,title:c.name}),h.current&&h.current.notificationManager.open({text:"✅ Image uploaded successfully",type:"success",timeout:3e3})}else throw Error("Missing image location in response")}catch(a){console.error("Upload error:",a),h.current&&h.current.notificationManager.open({text:"❌ Image upload failed",type:"error",timeout:5e3})}},b.click()}},setup:b=>{h.current=b,b.ui.registry.addButton("deleteimage",{text:"\uD83D\uDDD1️",tooltip:"Delete Selected Image",onAction:async()=>{let a=b.selection.getNode();if(a&&"IMG"===a.nodeName){let c=a.src,d=c.split("/").pop()||"this image";if(confirm(`⚠️ Delete "${d}"?

This action cannot be undone and will permanently remove the image from both the editor and server.`))try{if(await r(c)){b.dom.remove(a),b.nodeChanged(),j.current=!0;let c=b.getContent();i.current(c),setTimeout(()=>j.current=!1,100),b.notificationManager.open({text:"✅ Image deleted successfully",type:"success",timeout:3e3})}else b.notificationManager.open({text:"❌ Failed to delete image from server",type:"error",timeout:5e3})}catch(a){console.error("Delete image error:",a),b.notificationManager.open({text:"❌ Error deleting image",type:"error",timeout:5e3})}}else b.notificationManager.open({text:"\uD83D\uDCDD Please select an image first",type:"warning",timeout:2e3})}}),b.on("keydown",async a=>{if(8===a.keyCode||46===a.keyCode){let c=b.selection.getNode();if(c&&"IMG"===c.nodeName){a.preventDefault();let d=c.src,e=d.split("/").pop()||"this image";if(confirm(`⚠️ Delete "${e}"?

This action cannot be undone and will permanently remove the image from both the editor and server.`))try{if(await r(d)){b.dom.remove(c),b.nodeChanged(),j.current=!0;let a=b.getContent();i.current(a),setTimeout(()=>j.current=!1,100),b.notificationManager.open({text:"✅ Image deleted successfully",type:"success",timeout:3e3})}else b.notificationManager.open({text:"❌ Failed to delete image from server",type:"error",timeout:5e3})}catch(a){console.error("Delete image error:",a),b.notificationManager.open({text:"❌ Error deleting image",type:"error",timeout:5e3})}}}}),b.on("change input undo redo",()=>{j.current=!0;let a=b.getContent();i.current(a),setTimeout(()=>j.current=!1,50)}),b.on("init",()=>{p(!0),a&&b.setContent(a);let c=b.getContainer();c&&(c.style.backgroundColor="#1e293b",c.style.border="1px solid #475569",c.style.borderRadius="12px",c.style.overflow="hidden")})}})};return(()=>{if(window.tinymce&&h.current&&window.tinymce.remove(`#${q}`),window.tinymce)return b();let a=document.createElement("script");a.src="/tinymce/tinymce.min.js",a.onload=()=>{l(!0),setTimeout(()=>{b()},100)},a.onerror=()=>{console.error("❌ Failed to load TinyMCE")},document.head.appendChild(a)})(),()=>{window.tinymce&&h.current&&window.tinymce.remove(`#${q}`)}},[m,q,c,f]),(0,e.useEffect)(()=>{h.current&&o&&!j.current&&a!==h.current.getContent()&&h.current.setContent(a||"")},[a,o]),m)?(0,d.jsxs)("div",{className:g,children:[!o&&(0,d.jsx)("div",{className:"border border-slate-700 rounded-xl bg-slate-800/50 p-4 flex items-center justify-center",style:{height:f},children:(0,d.jsxs)("div",{className:"flex items-center gap-2 text-violet-400",children:[(0,d.jsx)("div",{className:"w-4 h-4 border-2 border-violet-400 border-t-transparent rounded-full animate-spin"}),(0,d.jsx)("span",{children:"Loading TinyMCE editor..."})]})}),(0,d.jsx)("div",{className:"rounded-xl overflow-hidden border border-slate-700",style:{visibility:o?"visible":"hidden",opacity:+!!o,transition:"opacity 0.3s ease",backgroundColor:"#1e293b"},children:(0,d.jsx)("textarea",{id:q,className:"w-full",suppressHydrationWarning:!0})})]}):(0,d.jsx)("div",{className:`border border-slate-700 rounded-xl bg-slate-800/50 p-4 ${g}`,style:{height:f+50},children:(0,d.jsx)("div",{className:"flex items-center justify-center h-full",children:(0,d.jsxs)("div",{className:"flex items-center gap-2 text-violet-400",children:[(0,d.jsx)("div",{className:"w-4 h-4 border-2 border-violet-400 border-t-transparent rounded-full animate-spin"}),(0,d.jsx)("span",{children:"Initializing editor..."})]})})})},g=({label:a,value:b,onChange:c,placeholder:e="Start typing your description...",required:g=!1,height:h=350,showHelpText:i,className:j=""})=>(0,d.jsxs)("div",{className:j,children:[(0,d.jsxs)("label",{className:"block text-sm font-medium text-slate-300 mb-2",children:[a," ",g&&(0,d.jsx)("span",{className:"text-red-400",children:"*"})]}),(0,d.jsx)(f,{value:b,onChange:c,placeholder:e,height:h,className:"w-full"}),i&&(0,d.jsx)("p",{className:"text-xs text-slate-400 mt-1",children:i})]})}};