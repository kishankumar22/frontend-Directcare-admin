(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_e26bd139._.js",
  "static/chunks/node_modules_lucide-react_dist_esm_icons_e6d10313._.js"
],
    source: "dynamic"
});
