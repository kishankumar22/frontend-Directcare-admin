(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/components/HomeBannerSlider.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>HomeBannerSlider
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
function HomeBannerSlider(param) {
    let { banners, baseUrl } = param;
    _s();
    if (!banners || banners.length === 0) return null;
    // ✅ Infinite loop clone logic
    const extended = [
        banners[banners.length - 1],
        ...banners,
        banners[0]
    ];
    const [index, setIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(1);
    const [animate, setAnimate] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    // ✅ Auto slide
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "HomeBannerSlider.useEffect": ()=>{
            const timer = setInterval({
                "HomeBannerSlider.useEffect.timer": ()=>{
                    setIndex({
                        "HomeBannerSlider.useEffect.timer": (prev)=>prev + 1
                    }["HomeBannerSlider.useEffect.timer"]);
                }
            }["HomeBannerSlider.useEffect.timer"], 5000);
            return ({
                "HomeBannerSlider.useEffect": ()=>clearInterval(timer)
            })["HomeBannerSlider.useEffect"];
        }
    }["HomeBannerSlider.useEffect"], []);
    // ✅ Loop logic
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "HomeBannerSlider.useEffect": ()=>{
            if (index === extended.length - 1) {
                setTimeout({
                    "HomeBannerSlider.useEffect": ()=>setAnimate(false)
                }["HomeBannerSlider.useEffect"], 690);
                setTimeout({
                    "HomeBannerSlider.useEffect": ()=>setIndex(1)
                }["HomeBannerSlider.useEffect"], 700);
                setTimeout({
                    "HomeBannerSlider.useEffect": ()=>setAnimate(true)
                }["HomeBannerSlider.useEffect"], 710);
            }
            if (index === 0) {
                setTimeout({
                    "HomeBannerSlider.useEffect": ()=>setAnimate(false)
                }["HomeBannerSlider.useEffect"], 690);
                setTimeout({
                    "HomeBannerSlider.useEffect": ()=>setIndex(banners.length)
                }["HomeBannerSlider.useEffect"], 700);
                setTimeout({
                    "HomeBannerSlider.useEffect": ()=>setAnimate(true)
                }["HomeBannerSlider.useEffect"], 710);
            }
        }
    }["HomeBannerSlider.useEffect"], [
        index
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: " relative  w-full  h-[150px]        /* ✅ Mobile height EXACT DirectCare style */ md:h-[500px]     /* ✅ Desktop untouched */ overflow-hidden  group ",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex h-full ".concat(animate ? "transition-transform duration-700" : ""),
                style: {
                    transform: "translateX(-".concat(index * 100, "%)")
                },
                children: extended.map((banner, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                        href: banner.link || "#",
                        target: "_blank",
                        className: "min-w-full h-full flex-shrink-0 block",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                            src: "".concat(baseUrl).concat(banner.imageUrl),
                            alt: "",
                            className: "w-full h-full object-cover object-center"
                        }, void 0, false, {
                            fileName: "[project]/components/HomeBannerSlider.tsx",
                            lineNumber: 74,
                            columnNumber: 13
                        }, this)
                    }, i, false, {
                        fileName: "[project]/components/HomeBannerSlider.tsx",
                        lineNumber: 68,
                        columnNumber: 11
                    }, this))
            }, void 0, false, {
                fileName: "[project]/components/HomeBannerSlider.tsx",
                lineNumber: 63,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                onClick: ()=>setIndex((prev)=>prev - 1),
                className: "absolute left-3 top-1/2 -translate-y-1/2 bg-white/70 p-2 rounded-full opacity-0 group-hover:opacity-100 transition",
                children: "❮"
            }, void 0, false, {
                fileName: "[project]/components/HomeBannerSlider.tsx",
                lineNumber: 84,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                onClick: ()=>setIndex((prev)=>prev + 1),
                className: "absolute right-3 top-1/2 -translate-y-1/2 bg-white/70 p-2 rounded-full opacity-0 group-hover:opacity-100 transition",
                children: "❯"
            }, void 0, false, {
                fileName: "[project]/components/HomeBannerSlider.tsx",
                lineNumber: 92,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "absolute bottom-2 w-full flex justify-center gap-2",
                children: banners.map((_, idx)=>{
                    const realIndex = idx + 1;
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>setIndex(realIndex),
                        className: "w-3 h-3 rounded-full transition ".concat(index === realIndex ? "bg-white" : "bg-white/40")
                    }, idx, false, {
                        fileName: "[project]/components/HomeBannerSlider.tsx",
                        lineNumber: 104,
                        columnNumber: 13
                    }, this);
                })
            }, void 0, false, {
                fileName: "[project]/components/HomeBannerSlider.tsx",
                lineNumber: 100,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/HomeBannerSlider.tsx",
        lineNumber: 52,
        columnNumber: 5
    }, this);
}
_s(HomeBannerSlider, "qRe2EDjLgu92pMKJA35hdy/EXOs=");
_c = HomeBannerSlider;
var _c;
__turbopack_context__.k.register(_c, "HomeBannerSlider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=components_HomeBannerSlider_tsx_f68f3a3b._.js.map