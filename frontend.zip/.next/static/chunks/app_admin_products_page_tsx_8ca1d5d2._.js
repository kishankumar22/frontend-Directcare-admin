(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_ca377a9b._.js",
  "static/chunks/node_modules_lucide-react_dist_esm_icons_bbd4d399._.js"
],
    source: "dynamic"
});
