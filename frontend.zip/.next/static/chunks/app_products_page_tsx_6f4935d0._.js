(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_9fd412fa._.js",
  "static/chunks/node_modules_ede2d300._.js"
],
    source: "dynamic"
});
