(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_6be3c1f1._.js",
  "static/chunks/_8bd3babb._.js"
],
    source: "dynamic"
});
