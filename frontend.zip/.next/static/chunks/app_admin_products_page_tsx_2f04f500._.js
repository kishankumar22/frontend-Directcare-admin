(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_1292f915._.js",
  "static/chunks/node_modules_lucide-react_dist_esm_icons_ce210802._.js"
],
    source: "dynamic"
});
