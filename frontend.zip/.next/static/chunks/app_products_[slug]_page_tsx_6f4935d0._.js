(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_29744ee1._.js",
  "static/chunks/node_modules_d17dd3c8._.js"
],
    source: "dynamic"
});
