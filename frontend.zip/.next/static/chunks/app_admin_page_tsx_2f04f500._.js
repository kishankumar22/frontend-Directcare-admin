(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_recharts_es6_e1ba59dd._.js",
  "static/chunks/node_modules_f91449dd._.js",
  "static/chunks/app_admin_page_tsx_dd146c39._.js"
],
    source: "dynamic"
});
