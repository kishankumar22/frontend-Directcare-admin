(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_c1cbba8b._.js",
  "static/chunks/_8bd3babb._.js"
],
    source: "dynamic"
});
