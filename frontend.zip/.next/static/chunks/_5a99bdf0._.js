(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/components/ui/tabs.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Tabs",
    ()=>Tabs,
    "TabsContent",
    ()=>TabsContent,
    "TabsList",
    ()=>TabsList,
    "TabsTrigger",
    ()=>TabsTrigger
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$tabs$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@radix-ui/react-tabs/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/utils.ts [app-client] (ecmascript)");
;
;
;
;
const Tabs = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$tabs$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Root"];
const TabsList = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c = (param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$tabs$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["List"], {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("inline-flex h-10 items-center justify-center rounded-md bg-muted p-1 text-muted-foreground", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/tabs.tsx",
        lineNumber: 12,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
});
_c1 = TabsList;
TabsList.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$tabs$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["List"].displayName;
const TabsTrigger = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c2 = (param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$tabs$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Trigger"], {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("inline-flex items-center justify-center whitespace-nowrap rounded-sm px-3 py-1.5 text-sm font-medium ring-offset-background transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 data-[state=active]:bg-background data-[state=active]:text-foreground data-[state=active]:shadow-sm", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/tabs.tsx",
        lineNumber: 27,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
});
_c3 = TabsTrigger;
TabsTrigger.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$tabs$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Trigger"].displayName;
const TabsContent = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c4 = (param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$tabs$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Content"], {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("mt-2 ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/tabs.tsx",
        lineNumber: 42,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
});
_c5 = TabsContent;
TabsContent.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$tabs$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Content"].displayName;
;
var _c, _c1, _c2, _c3, _c4, _c5;
__turbopack_context__.k.register(_c, "TabsList$React.forwardRef");
__turbopack_context__.k.register(_c1, "TabsList");
__turbopack_context__.k.register(_c2, "TabsTrigger$React.forwardRef");
__turbopack_context__.k.register(_c3, "TabsTrigger");
__turbopack_context__.k.register(_c4, "TabsContent$React.forwardRef");
__turbopack_context__.k.register(_c5, "TabsContent");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/api.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// lib/api.ts
__turbopack_context__.s([
    "ApiClient",
    ()=>ApiClient,
    "apiClient",
    ()=>apiClient
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@swc/helpers/esm/_define_property.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/axios/lib/axios.js [app-client] (ecmascript)");
;
;
const API_BASE_URL = ("TURBOPACK compile-time value", "https://testapi.knowledgemarkg.com") || 'https://testapi.knowledgemarkg.com';
class ApiClient {
    setupInterceptors() {
        // REQUEST INTERCEPTOR
        this.client.interceptors.request.use((config)=>{
            var _config_method;
            // ✅ Force unlimited size on every request
            config.maxContentLength = Infinity;
            config.maxBodyLength = Infinity;
            const fullUrl = "".concat(config.baseURL).concat(config.url);
            console.log("🚀 API Request: ".concat((_config_method = config.method) === null || _config_method === void 0 ? void 0 : _config_method.toUpperCase(), " ").concat(fullUrl));
            if ("TURBOPACK compile-time truthy", 1) {
                const token = localStorage.getItem('authToken');
                if (token && config.headers) {
                    config.headers.Authorization = "Bearer ".concat(token);
                }
            }
            return config;
        }, (error)=>{
            console.error('❌ Request interceptor error:', error);
            return Promise.reject(error);
        });
        // RESPONSE INTERCEPTOR
        this.client.interceptors.response.use((response)=>{
            var _response_config;
            console.log("✅ API Response: ".concat(response.status, " ").concat((_response_config = response.config) === null || _response_config === void 0 ? void 0 : _response_config.url));
            if (response.status >= 400 && response.status < 500) {
                console.warn("⚠️ Client error: ".concat(response.status), response.data);
            }
            return response;
        }, (error)=>{
            var _error_response, _error_response1;
            if (error.response) {
                var _error_config;
                console.error("❌ API Error: ".concat(error.response.status, " ").concat((_error_config = error.config) === null || _error_config === void 0 ? void 0 : _error_config.url), {
                    status: error.response.status,
                    statusText: error.response.statusText,
                    data: error.response.data
                });
            } else if (error.request) {
                console.error('❌ Network Error:', {
                    message: error.message,
                    code: error.code
                });
            } else {
                console.error('❌ Request Setup Error:', error.message);
            }
            if (((_error_response = error.response) === null || _error_response === void 0 ? void 0 : _error_response.status) === 413) {
                console.error('❌ 413: Payload Too Large - Data size exceeds server limit');
            }
            if (((_error_response1 = error.response) === null || _error_response1 === void 0 ? void 0 : _error_response1.status) === 401 && "object" !== 'undefined') {
                localStorage.removeItem('authToken');
                window.location.href = '/login';
            }
            return Promise.reject(error);
        });
    }
    async request(method, endpoint, data, options) {
        try {
            var _response_data;
            console.log("🔄 Making ".concat(method, " request to: ").concat(endpoint));
            const response = await this.client({
                method,
                url: endpoint,
                data,
                maxContentLength: Infinity,
                maxBodyLength: Infinity,
                ...options
            });
            if (((_response_data = response.data) === null || _response_data === void 0 ? void 0 : _response_data.success) === false) {
                var _response_data1, _response_data2;
                const apiError = ((_response_data1 = response.data) === null || _response_data1 === void 0 ? void 0 : _response_data1.message) || ((_response_data2 = response.data) === null || _response_data2 === void 0 ? void 0 : _response_data2.error) || 'API operation failed';
                return {
                    error: apiError,
                    status: response.status,
                    data: response.data
                };
            }
            if (response.status >= 400 && response.status < 500) {
                var _response_data3, _response_data4;
                const errorMessage = ((_response_data3 = response.data) === null || _response_data3 === void 0 ? void 0 : _response_data3.message) || ((_response_data4 = response.data) === null || _response_data4 === void 0 ? void 0 : _response_data4.error) || "Request failed with status ".concat(response.status);
                return {
                    error: errorMessage,
                    status: response.status
                };
            }
            return {
                data: response.data,
                message: 'Request successful',
                status: response.status
            };
        } catch (error) {
            var _error_response, _error_response1, _error_response2;
            const errorDetails = {
                endpoint: endpoint || 'unknown',
                method: method || 'unknown',
                message: (error === null || error === void 0 ? void 0 : error.message) || 'Unknown error',
                code: (error === null || error === void 0 ? void 0 : error.code) || 'NO_CODE',
                status: (error === null || error === void 0 ? void 0 : (_error_response = error.response) === null || _error_response === void 0 ? void 0 : _error_response.status) || 'NO_STATUS',
                responseData: (error === null || error === void 0 ? void 0 : (_error_response1 = error.response) === null || _error_response1 === void 0 ? void 0 : _error_response1.data) || null
            };
            console.error('❌ Request failed:', JSON.stringify(errorDetails, null, 2));
            let errorMessage = 'An unexpected error occurred';
            let status = error === null || error === void 0 ? void 0 : (_error_response2 = error.response) === null || _error_response2 === void 0 ? void 0 : _error_response2.status;
            if (error === null || error === void 0 ? void 0 : error.response) {
                var _errorData_errors;
                const errorData = error.response.data;
                errorMessage = (errorData === null || errorData === void 0 ? void 0 : errorData.message) || (errorData === null || errorData === void 0 ? void 0 : errorData.error) || (errorData === null || errorData === void 0 ? void 0 : (_errorData_errors = errorData.errors) === null || _errorData_errors === void 0 ? void 0 : _errorData_errors[0]) || "HTTP ".concat(error.response.status, ": ").concat(error.response.statusText);
                if (error.response.status === 413) {
                    errorMessage = 'Request too large. Server limit exceeded. Please reduce content size.';
                } else if (error.response.status === 404) {
                    errorMessage = "Endpoint not found: ".concat(endpoint);
                } else if (error.response.status === 500) {
                    errorMessage = 'Internal server error. Please try again later.';
                } else if (error.response.status === 400) {
                    errorMessage = (errorData === null || errorData === void 0 ? void 0 : errorData.message) || 'Bad request. Please check your input.';
                }
            } else if (error === null || error === void 0 ? void 0 : error.request) {
                if (error.code === 'ERR_FR_MAX_BODY_LENGTH_EXCEEDED') {
                    errorMessage = 'Request data too large. This should not happen with current settings. Check server configuration.';
                } else if (error.code === 'ECONNABORTED') {
                    errorMessage = 'Request timeout (2 min). Your data may be too large or connection is slow.';
                } else if (error.code === 'ERR_NETWORK') {
                    errorMessage = 'Network error. Check:\n1. Internet connection\n2. CORS configuration\n3. Server is running';
                } else {
                    errorMessage = 'No response from server. Please try again.';
                }
            } else {
                errorMessage = (error === null || error === void 0 ? void 0 : error.message) || 'Failed to setup request';
            }
            return {
                error: errorMessage,
                status
            };
        }
    }
    async get(endpoint, options) {
        return this.request('GET', endpoint, undefined, options);
    }
    async post(endpoint, body, options) {
        return this.request('POST', endpoint, body, options);
    }
    async put(endpoint, body, options) {
        return this.request('PUT', endpoint, body, options);
    }
    async patch(endpoint, body, options) {
        return this.request('PATCH', endpoint, body, options);
    }
    async delete(endpoint, options) {
        return this.request('DELETE', endpoint, undefined, options);
    }
    setAuthToken(token) {
        if ("TURBOPACK compile-time truthy", 1) {
            localStorage.setItem('authToken', token);
        }
    }
    clearAuthToken() {
        if ("TURBOPACK compile-time truthy", 1) {
            localStorage.removeItem('authToken');
        }
    }
    getAuthToken() {
        if ("TURBOPACK compile-time truthy", 1) {
            return localStorage.getItem('authToken');
        }
        //TURBOPACK unreachable
        ;
    }
    async uploadFile(endpoint, file, additionalData) {
        const formData = new FormData();
        formData.append('file', file);
        if (additionalData) {
            Object.entries(additionalData).forEach((param)=>{
                let [key, value] = param;
                formData.append(key, String(value));
            });
        }
        return this.request('POST', endpoint, formData, {
            headers: {
                'Content-Type': 'multipart/form-data'
            },
            maxContentLength: Infinity,
            maxBodyLength: Infinity
        });
    }
    async uploadMultipleFiles(endpoint, files, additionalData) {
        const formData = new FormData();
        files.forEach((file)=>{
            formData.append('files', file);
        });
        if (additionalData) {
            Object.entries(additionalData).forEach((param)=>{
                let [key, value] = param;
                formData.append(key, String(value));
            });
        }
        return this.request('POST', endpoint, formData, {
            headers: {
                'Content-Type': 'multipart/form-data'
            },
            maxContentLength: Infinity,
            maxBodyLength: Infinity
        });
    }
    constructor(baseURL){
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "client", void 0);
        this.client = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].create({
            baseURL,
            timeout: 120000,
            headers: {
                'Content-Type': 'application/json'
            },
            // ✅ CRITICAL: Set to Infinity for unlimited size
            maxContentLength: Infinity,
            maxBodyLength: Infinity,
            validateStatus: (status)=>{
                return status < 500;
            }
        });
        this.setupInterceptors();
    }
}
const apiClient = new ApiClient(API_BASE_URL);
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/admin/products/SelfHostedEditor.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// components/SelfHostedTinyMCE.tsx
__turbopack_context__.s([
    "ProductDescriptionEditor",
    ()=>ProductDescriptionEditor,
    "SelfHostedTinyMCE",
    ()=>SelfHostedTinyMCE
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
const SelfHostedTinyMCE = (param)=>{
    let { value, onChange, placeholder = "Start typing...", height = 400, className = "" } = param;
    _s();
    const editorRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const onChangeRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(onChange); // ✅ Store onChange in ref
    const isUpdatingRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(false);
    const [isLoaded, setIsLoaded] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isMounted, setIsMounted] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isReady, setIsReady] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [editorId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        "SelfHostedTinyMCE.useState": ()=>"tinymce-".concat(Date.now(), "-").concat(Math.random().toString(36).substr(2, 9))
    }["SelfHostedTinyMCE.useState"]);
    // ✅ Update onChange ref
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "SelfHostedTinyMCE.useEffect": ()=>{
            onChangeRef.current = onChange;
        }
    }["SelfHostedTinyMCE.useEffect"], [
        onChange
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "SelfHostedTinyMCE.useEffect": ()=>{
            setIsMounted(true);
        }
    }["SelfHostedTinyMCE.useEffect"], []);
    const deleteImageFromServer = async (imageUrl)=>{
        try {
            const apiUrl = ("TURBOPACK compile-time value", "https://testapi.knowledgemarkg.com") || 'https://testapi.knowledgemarkg.com';
            const urlParts = imageUrl.split('/');
            const fileName = urlParts[urlParts.length - 1];
            if (!fileName) {
                console.error('Could not extract filename from URL:', imageUrl);
                return false;
            }
            const response = await fetch("".concat(apiUrl, "/api/Editor/delete-image?fileName=").concat(fileName), {
                method: 'DELETE',
                headers: {
                    'Authorization': "Bearer ".concat(localStorage.getItem('authToken')),
                    'Content-Type': 'application/json'
                }
            });
            if (!response.ok) {
                console.error('Failed to delete image:', response.statusText);
                return false;
            }
            console.log('✅ Image deleted successfully:', fileName);
            return true;
        } catch (error) {
            console.error('❌ Error deleting image:', error);
            return false;
        }
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "SelfHostedTinyMCE.useEffect": ()=>{
            if (!isMounted) return;
            const loadTinyMCE = {
                "SelfHostedTinyMCE.useEffect.loadTinyMCE": ()=>{
                    if (window.tinymce && editorRef.current) {
                        window.tinymce.remove("#".concat(editorId));
                    }
                    if (window.tinymce) {
                        initializeEditor();
                        return;
                    }
                    const script = document.createElement('script');
                    script.src = '/tinymce/tinymce.min.js';
                    script.onload = ({
                        "SelfHostedTinyMCE.useEffect.loadTinyMCE": ()=>{
                            setIsLoaded(true);
                            setTimeout({
                                "SelfHostedTinyMCE.useEffect.loadTinyMCE": ()=>{
                                    initializeEditor();
                                }
                            }["SelfHostedTinyMCE.useEffect.loadTinyMCE"], 100);
                        }
                    })["SelfHostedTinyMCE.useEffect.loadTinyMCE"];
                    script.onerror = ({
                        "SelfHostedTinyMCE.useEffect.loadTinyMCE": ()=>{
                            console.error('❌ Failed to load TinyMCE');
                        }
                    })["SelfHostedTinyMCE.useEffect.loadTinyMCE"];
                    document.head.appendChild(script);
                }
            }["SelfHostedTinyMCE.useEffect.loadTinyMCE"];
            const initializeEditor = {
                "SelfHostedTinyMCE.useEffect.initializeEditor": ()=>{
                    if (!window.tinymce) return;
                    window.tinymce.init({
                        selector: "#".concat(editorId),
                        height: height,
                        license_key: 'gpl',
                        base_url: '/tinymce',
                        suffix: '.min',
                        plugins: [
                            'advlist',
                            'autolink',
                            'lists',
                            'link',
                            'image',
                            'charmap',
                            'searchreplace',
                            'visualblocks',
                            'code',
                            'fullscreen',
                            'insertdatetime',
                            'media',
                            'table',
                            'wordcount',
                            'help'
                        ],
                        toolbar: 'undo redo | formatselect | bold italic underline | ' + 'alignleft aligncenter alignright | ' + 'bullist numlist | link image | deleteimage | removeformat | code',
                        skin: 'oxide-dark',
                        content_css: 'dark',
                        menubar: 'edit view insert format tools',
                        content_style: "\n          body { \n            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;\n            font-size: 14px; \n            line-height: 1.6;\n            color: #f1f5f9 !important;\n            background-color: #0f172a !important;\n            margin: 0;\n            padding: 16px;\n            min-height: ".concat(height - 120, 'px;\n            box-sizing: border-box;\n          }\n          \n          body:empty::before {\n            content: "').concat(placeholder, "\";\n            color: #ffffff;\n            opacity: 0.6;\n          }\n          \n          * {\n            color: #f1f5f9 !important;\n          }\n          \n          p {\n            margin: 0 0 1em 0;\n            line-height: 1.6;\n            color: #e2e8f0 !important;\n            min-height: 1.4em;\n          }\n          \n          p:first-child {\n            margin-top: 0;\n          }\n          \n          p:last-child {\n            margin-bottom: 0;\n          }\n          \n          p:empty {\n            min-height: 1.4em;\n          }\n          \n          h1, h2, h3, h4, h5, h6 { \n            color: #f8fafc !important; \n            margin: 1.2em 0 0.6em 0; \n            font-weight: 600;\n            line-height: 1.4;\n          }\n          \n          strong, b {\n            color: #f8fafc !important;\n            font-weight: 600;\n          }\n          \n          em, i {\n            color: #e2e8f0 !important;\n            font-style: italic;\n          }\n          \n          u {\n            color: #e2e8f0 !important;\n            text-decoration: underline;\n          }\n          \n          a { \n            color: #a855f7 !important; \n            text-decoration: underline;\n          }\n          \n          a:hover {\n            color: #c084fc !important;\n          }\n          \n          ul, ol {\n            color: #e2e8f0 !important;\n            padding-left: 1.5em;\n            margin: 0.8em 0;\n          }\n          \n          li {\n            color: #e2e8f0 !important;\n            margin: 0.4em 0;\n            line-height: 1.6;\n          }\n          \n          table { \n            border-collapse: collapse; \n            width: 100%; \n            margin: 1em 0; \n            background-color: #1e293b !important;\n            border: 1px solid #475569;\n          }\n          \n          th, td { \n            border: 1px solid #475569; \n            padding: 8px 12px; \n            text-align: left; \n            color: #e2e8f0 !important;\n          }\n          \n          th { \n            background-color: #334155 !important; \n            font-weight: 600;\n            color: #f1f5f9 !important;\n          }\n          \n          tr:nth-child(even) td {\n            background-color: #334155 !important;\n          }\n          \n          code { \n            background-color: #374151 !important; \n            color: #fbbf24 !important; \n            padding: 2px 6px; \n            border-radius: 4px;\n            font-family: 'SF Mono', Monaco, Consolas, monospace;\n          }\n          \n          pre {\n            background-color: #111827 !important;\n            color: #f3f4f6 !important;\n            padding: 16px;\n            border-radius: 8px;\n            overflow-x: auto;\n            border: 1px solid #374151;\n          }\n          \n          blockquote {\n            border-left: 4px solid #8b5cf6;\n            margin: 1em 0;\n            padding: 0.5em 1em;\n            color: #cbd5e1 !important;\n            background-color: #334155 !important;\n            border-radius: 0 8px 8px 0;\n          }\n          \n          hr {\n            border: none;\n            border-top: 2px solid #475569;\n            margin: 1.5em 0;\n          }\n          \n          img {\n            max-width: 100%;\n            height: auto;\n            border-radius: 8px;\n            cursor: pointer;\n          }\n          \n          img:hover {\n            opacity: 0.8;\n            box-shadow: 0 0 0 2px #a855f7;\n          }\n          \n          img[data-mce-selected] {\n            box-shadow: 0 0 0 3px #a855f7 !important;\n          }\n        "),
                        branding: false,
                        promotion: false,
                        resize: true,
                        toolbar_mode: 'wrap',
                        statusbar: true,
                        elementpath: false,
                        images_upload_handler: {
                            "SelfHostedTinyMCE.useEffect.initializeEditor": async (blobInfo, progress)=>{
                                return new Promise({
                                    "SelfHostedTinyMCE.useEffect.initializeEditor": async (resolve, reject)=>{
                                        try {
                                            const formData = new FormData();
                                            formData.append('file', blobInfo.blob(), blobInfo.filename());
                                            const apiUrl = ("TURBOPACK compile-time value", "https://testapi.knowledgemarkg.com") || 'https://testapi.knowledgemarkg.com';
                                            const response = await fetch("".concat(apiUrl, "/api/Editor/upload-image"), {
                                                method: 'POST',
                                                headers: {
                                                    'Authorization': "Bearer ".concat(localStorage.getItem('authToken'))
                                                },
                                                body: formData
                                            });
                                            if (!response.ok) {
                                                reject("❌ Upload failed: ".concat(response.statusText));
                                                return;
                                            }
                                            let result;
                                            try {
                                                result = await response.json();
                                            } catch (e) {
                                                reject('❌ Upload failed: Invalid JSON response');
                                                return;
                                            }
                                            if (result === null || result === void 0 ? void 0 : result.location) {
                                                resolve("".concat(apiUrl).concat(result.location));
                                            } else {
                                                reject('❌ Upload failed: Missing image location');
                                            }
                                        } catch (error) {
                                            console.error('Upload error:', error);
                                            reject('❌ Upload failed: Network error');
                                        }
                                    }
                                }["SelfHostedTinyMCE.useEffect.initializeEditor"]);
                            }
                        }["SelfHostedTinyMCE.useEffect.initializeEditor"],
                        file_picker_types: 'image',
                        file_picker_callback: {
                            "SelfHostedTinyMCE.useEffect.initializeEditor": (callback, value, meta)=>{
                                if (meta.filetype === 'image') {
                                    const input = document.createElement('input');
                                    input.setAttribute('type', 'file');
                                    input.setAttribute('accept', 'image/png,image/jpeg,image/gif,image/webp');
                                    input.style.display = 'none';
                                    document.body.appendChild(input);
                                    input.onchange = ({
                                        "SelfHostedTinyMCE.useEffect.initializeEditor": async function() {
                                            var _files;
                                            const file = (_files = this.files) === null || _files === void 0 ? void 0 : _files[0];
                                            document.body.removeChild(input);
                                            if (!file) return;
                                            try {
                                                if (editorRef.current) {
                                                    editorRef.current.notificationManager.open({
                                                        text: '⏳ Uploading image...',
                                                        type: 'info',
                                                        timeout: 3000
                                                    });
                                                }
                                                const formData = new FormData();
                                                formData.append('file', file, file.name);
                                                const apiUrl = ("TURBOPACK compile-time value", "https://testapi.knowledgemarkg.com") || 'https://testapi.knowledgemarkg.com';
                                                const response = await fetch("".concat(apiUrl, "/api/Editor/upload-image"), {
                                                    method: 'POST',
                                                    headers: {
                                                        'Authorization': "Bearer ".concat(localStorage.getItem('authToken'))
                                                    },
                                                    body: formData
                                                });
                                                if (!response.ok) {
                                                    throw new Error("Upload failed: ".concat(response.statusText));
                                                }
                                                const result = await response.json();
                                                if (result === null || result === void 0 ? void 0 : result.location) {
                                                    const imageUrl = "".concat(apiUrl).concat(result.location);
                                                    callback(imageUrl, {
                                                        alt: file.name,
                                                        title: file.name
                                                    });
                                                    if (editorRef.current) {
                                                        editorRef.current.notificationManager.open({
                                                            text: '✅ Image uploaded successfully',
                                                            type: 'success',
                                                            timeout: 3000
                                                        });
                                                    }
                                                } else {
                                                    throw new Error('Missing image location in response');
                                                }
                                            } catch (error) {
                                                console.error('Upload error:', error);
                                                if (editorRef.current) {
                                                    editorRef.current.notificationManager.open({
                                                        text: '❌ Image upload failed',
                                                        type: 'error',
                                                        timeout: 5000
                                                    });
                                                }
                                            }
                                        }
                                    })["SelfHostedTinyMCE.useEffect.initializeEditor"];
                                    input.click();
                                }
                            }
                        }["SelfHostedTinyMCE.useEffect.initializeEditor"],
                        setup: {
                            "SelfHostedTinyMCE.useEffect.initializeEditor": (editor)=>{
                                editorRef.current = editor;
                                editor.ui.registry.addButton('deleteimage', {
                                    text: '🗑️',
                                    tooltip: 'Delete Selected Image',
                                    onAction: {
                                        "SelfHostedTinyMCE.useEffect.initializeEditor": async ()=>{
                                            const selectedImg = editor.selection.getNode();
                                            if (selectedImg && selectedImg.nodeName === 'IMG') {
                                                const imageUrl = selectedImg.src;
                                                const imageName = imageUrl.split('/').pop() || 'this image';
                                                const confirmed = confirm('⚠️ Delete "'.concat(imageName, '"?\n\n') + "This action cannot be undone and will permanently remove the image from both the editor and server.");
                                                if (confirmed) {
                                                    try {
                                                        const deleted = await deleteImageFromServer(imageUrl);
                                                        if (deleted) {
                                                            editor.dom.remove(selectedImg);
                                                            editor.nodeChanged();
                                                            isUpdatingRef.current = true;
                                                            const content = editor.getContent();
                                                            onChangeRef.current(content);
                                                            setTimeout({
                                                                "SelfHostedTinyMCE.useEffect.initializeEditor": ()=>isUpdatingRef.current = false
                                                            }["SelfHostedTinyMCE.useEffect.initializeEditor"], 100);
                                                            editor.notificationManager.open({
                                                                text: '✅ Image deleted successfully',
                                                                type: 'success',
                                                                timeout: 3000
                                                            });
                                                        } else {
                                                            editor.notificationManager.open({
                                                                text: '❌ Failed to delete image from server',
                                                                type: 'error',
                                                                timeout: 5000
                                                            });
                                                        }
                                                    } catch (error) {
                                                        console.error('Delete image error:', error);
                                                        editor.notificationManager.open({
                                                            text: '❌ Error deleting image',
                                                            type: 'error',
                                                            timeout: 5000
                                                        });
                                                    }
                                                }
                                            } else {
                                                editor.notificationManager.open({
                                                    text: '📝 Please select an image first',
                                                    type: 'warning',
                                                    timeout: 2000
                                                });
                                            }
                                        }
                                    }["SelfHostedTinyMCE.useEffect.initializeEditor"]
                                });
                                editor.on('keydown', {
                                    "SelfHostedTinyMCE.useEffect.initializeEditor": async (e)=>{
                                        if (e.keyCode === 8 || e.keyCode === 46) {
                                            const selectedNode = editor.selection.getNode();
                                            if (selectedNode && selectedNode.nodeName === 'IMG') {
                                                e.preventDefault();
                                                const imageUrl = selectedNode.src;
                                                const imageName = imageUrl.split('/').pop() || 'this image';
                                                const confirmed = confirm('⚠️ Delete "'.concat(imageName, '"?\n\n') + "This action cannot be undone and will permanently remove the image from both the editor and server.");
                                                if (confirmed) {
                                                    try {
                                                        const deleted = await deleteImageFromServer(imageUrl);
                                                        if (deleted) {
                                                            editor.dom.remove(selectedNode);
                                                            editor.nodeChanged();
                                                            isUpdatingRef.current = true;
                                                            const content = editor.getContent();
                                                            onChangeRef.current(content);
                                                            setTimeout({
                                                                "SelfHostedTinyMCE.useEffect.initializeEditor": ()=>isUpdatingRef.current = false
                                                            }["SelfHostedTinyMCE.useEffect.initializeEditor"], 100);
                                                            editor.notificationManager.open({
                                                                text: '✅ Image deleted successfully',
                                                                type: 'success',
                                                                timeout: 3000
                                                            });
                                                        } else {
                                                            editor.notificationManager.open({
                                                                text: '❌ Failed to delete image from server',
                                                                type: 'error',
                                                                timeout: 5000
                                                            });
                                                        }
                                                    } catch (error) {
                                                        console.error('Delete image error:', error);
                                                        editor.notificationManager.open({
                                                            text: '❌ Error deleting image',
                                                            type: 'error',
                                                            timeout: 5000
                                                        });
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }["SelfHostedTinyMCE.useEffect.initializeEditor"]);
                                editor.on('change input undo redo', {
                                    "SelfHostedTinyMCE.useEffect.initializeEditor": ()=>{
                                        isUpdatingRef.current = true;
                                        const content = editor.getContent();
                                        onChangeRef.current(content); // ✅ Use ref instead of direct onChange
                                        setTimeout({
                                            "SelfHostedTinyMCE.useEffect.initializeEditor": ()=>isUpdatingRef.current = false
                                        }["SelfHostedTinyMCE.useEffect.initializeEditor"], 50);
                                    }
                                }["SelfHostedTinyMCE.useEffect.initializeEditor"]);
                                editor.on('init', {
                                    "SelfHostedTinyMCE.useEffect.initializeEditor": ()=>{
                                        setIsReady(true);
                                        if (value) {
                                            editor.setContent(value);
                                        }
                                        const container = editor.getContainer();
                                        if (container) {
                                            container.style.backgroundColor = '#1e293b';
                                            container.style.border = '1px solid #475569';
                                            container.style.borderRadius = '12px';
                                            container.style.overflow = 'hidden';
                                        }
                                    }
                                }["SelfHostedTinyMCE.useEffect.initializeEditor"]);
                            }
                        }["SelfHostedTinyMCE.useEffect.initializeEditor"]
                    });
                }
            }["SelfHostedTinyMCE.useEffect.initializeEditor"];
            loadTinyMCE();
            return ({
                "SelfHostedTinyMCE.useEffect": ()=>{
                    if (window.tinymce && editorRef.current) {
                        window.tinymce.remove("#".concat(editorId));
                    }
                }
            })["SelfHostedTinyMCE.useEffect"];
        }
    }["SelfHostedTinyMCE.useEffect"], [
        isMounted,
        editorId,
        placeholder,
        height
    ]); // ✅ Removed onChange dependency
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "SelfHostedTinyMCE.useEffect": ()=>{
            if (editorRef.current && isReady && !isUpdatingRef.current) {
                const currentContent = editorRef.current.getContent();
                if (value !== currentContent) {
                    editorRef.current.setContent(value || '');
                }
            }
        }
    }["SelfHostedTinyMCE.useEffect"], [
        value,
        isReady
    ]);
    if (!isMounted) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "border border-slate-700 rounded-xl bg-slate-800/50 p-4 ".concat(className),
            style: {
                height: height + 50
            },
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center justify-center h-full",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center gap-2 text-violet-400",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "w-4 h-4 border-2 border-violet-400 border-t-transparent rounded-full animate-spin"
                        }, void 0, false, {
                            fileName: "[project]/app/admin/products/SelfHostedEditor.tsx",
                            lineNumber: 581,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            children: "Initializing editor..."
                        }, void 0, false, {
                            fileName: "[project]/app/admin/products/SelfHostedEditor.tsx",
                            lineNumber: 582,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/admin/products/SelfHostedEditor.tsx",
                    lineNumber: 580,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/app/admin/products/SelfHostedEditor.tsx",
                lineNumber: 579,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/app/admin/products/SelfHostedEditor.tsx",
            lineNumber: 578,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0));
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: className,
        children: [
            !isReady && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "border border-slate-700 rounded-xl bg-slate-800/50 p-4 flex items-center justify-center",
                style: {
                    height: height
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center gap-2 text-violet-400",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "w-4 h-4 border-2 border-violet-400 border-t-transparent rounded-full animate-spin"
                        }, void 0, false, {
                            fileName: "[project]/app/admin/products/SelfHostedEditor.tsx",
                            lineNumber: 597,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            children: "Loading TinyMCE editor..."
                        }, void 0, false, {
                            fileName: "[project]/app/admin/products/SelfHostedEditor.tsx",
                            lineNumber: 598,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/admin/products/SelfHostedEditor.tsx",
                    lineNumber: 596,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/app/admin/products/SelfHostedEditor.tsx",
                lineNumber: 592,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "rounded-xl overflow-hidden border border-slate-700",
                style: {
                    visibility: isReady ? 'visible' : 'hidden',
                    opacity: isReady ? 1 : 0,
                    transition: 'opacity 0.3s ease',
                    backgroundColor: '#1e293b'
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                    id: editorId,
                    className: "w-full",
                    suppressHydrationWarning: true
                }, void 0, false, {
                    fileName: "[project]/app/admin/products/SelfHostedEditor.tsx",
                    lineNumber: 613,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/app/admin/products/SelfHostedEditor.tsx",
                lineNumber: 603,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/app/admin/products/SelfHostedEditor.tsx",
        lineNumber: 590,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(SelfHostedTinyMCE, "LxeOUdKmX45H5OCL3Qw0sWPJtyk=");
_c = SelfHostedTinyMCE;
const ProductDescriptionEditor = (param)=>{
    let { label, value, onChange, placeholder = "Start typing your description...", required = false, height = 350, showHelpText, className = "" } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: className,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                className: "block text-sm font-medium text-slate-300 mb-2",
                children: [
                    label,
                    " ",
                    required && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "text-red-400",
                        children: "*"
                    }, void 0, false, {
                        fileName: "[project]/app/admin/products/SelfHostedEditor.tsx",
                        lineNumber: 645,
                        columnNumber: 30
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/app/admin/products/SelfHostedEditor.tsx",
                lineNumber: 644,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SelfHostedTinyMCE, {
                value: value,
                onChange: onChange,
                placeholder: placeholder,
                height: height,
                className: "w-full"
            }, void 0, false, {
                fileName: "[project]/app/admin/products/SelfHostedEditor.tsx",
                lineNumber: 647,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            showHelpText && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-xs text-slate-400 mt-1",
                children: showHelpText
            }, void 0, false, {
                fileName: "[project]/app/admin/products/SelfHostedEditor.tsx",
                lineNumber: 655,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/app/admin/products/SelfHostedEditor.tsx",
        lineNumber: 643,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_c1 = ProductDescriptionEditor;
var _c, _c1;
__turbopack_context__.k.register(_c, "SelfHostedTinyMCE");
__turbopack_context__.k.register(_c1, "ProductDescriptionEditor");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/api-config.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "API_BASE_URL",
    ()=>API_BASE_URL,
    "API_ENDPOINTS",
    ()=>API_ENDPOINTS,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
const API_BASE_URL = ("TURBOPACK compile-time value", "https://testapi.knowledgemarkg.com") || 'https://localhost:7196';
const API_ENDPOINTS = {
    // Auth
    login: "".concat(API_BASE_URL, "/api/auth/login"),
    register: "".concat(API_BASE_URL, "/api/auth/register"),
    // Categories
    categories: "".concat(API_BASE_URL, "/api/categories"),
    // Brands
    brands: "".concat(API_BASE_URL, "/api/brands"),
    // Manufacturers
    manufacturers: "".concat(API_BASE_URL, "/api/manufacturers"),
    // Products
    products: "".concat(API_BASE_URL, "/api/products"),
    // Orders
    orders: "".concat(API_BASE_URL, "/api/orders"),
    // Customers
    customers: "".concat(API_BASE_URL, "/api/customers"),
    banners: "".concat(API_BASE_URL, "/api/banners"),
    uploadImage: "".concat(API_BASE_URL, "/api/upload-image")
};
const __TURBOPACK__default__export__ = API_BASE_URL;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/admin/products/edit/[id]/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>EditProductPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/tabs.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$left$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowLeft$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/arrow-left.js [app-client] (ecmascript) <export default as ArrowLeft>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$save$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Save$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/save.js [app-client] (ecmascript) <export default as Save>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$upload$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Upload$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/upload.js [app-client] (ecmascript) <export default as Upload>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/x.js [app-client] (ecmascript) <export default as X>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$info$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Info$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/info.js [app-client] (ecmascript) <export default as Info>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$search$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Search$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/search.js [app-client] (ecmascript) <export default as Search>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Image$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/image.js [app-client] (ecmascript) <export default as Image>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$package$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Package$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/package.js [app-client] (ecmascript) <export default as Package>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$tag$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tag$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/tag.js [app-client] (ecmascript) <export default as Tag>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chart$2d$column$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BarChart3$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/chart-column.js [app-client] (ecmascript) <export default as BarChart3>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$globe$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Globe$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/globe.js [app-client] (ecmascript) <export default as Globe>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$truck$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Truck$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/truck.js [app-client] (ecmascript) <export default as Truck>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$dollar$2d$sign$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DollarSign$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/dollar-sign.js [app-client] (ecmascript) <export default as DollarSign>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Link$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/link.js [app-client] (ecmascript) <export default as Link>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$shopping$2d$cart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ShoppingCart$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/shopping-cart.js [app-client] (ecmascript) <export default as ShoppingCart>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$video$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Video$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/video.js [app-client] (ecmascript) <export default as Video>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/api.ts [app-client] (ecmascript)"); // Import your axios client
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$admin$2f$products$2f$SelfHostedEditor$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/admin/products/SelfHostedEditor.tsx [app-client] (ecmascript)");
// import { ProductDescriptionEditor, RichTextEditor } from "../../RichTextEditor";
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$CustomToast$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/CustomToast.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2d$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/api-config.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
function EditProductPage(param) {
    let { params } = param;
    _s();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const toast = (0, __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$CustomToast$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useToast"])();
    const { id: productId } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["use"])(params);
    const [searchTerm, setSearchTerm] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [searchTermCross, setSearchTermCross] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [attributes, setAttributes] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const fileInputRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    // Helper function to format datetime for React inputs
    const formatDateTimeForInput = (dateString)=>{
        if (!dateString) return '';
        try {
            // Remove timezone info, milliseconds and keep only YYYY-MM-DDTHH:MM
            if (dateString.includes('T')) {
                const [datePart, timePart] = dateString.split('T');
                const cleanTime = timePart.split('.')[0]; // Remove milliseconds
                const shortTime = cleanTime.length > 5 ? cleanTime.substring(0, 5) : cleanTime; // Keep only HH:MM
                return "".concat(datePart, "T").concat(shortTime);
            }
            return dateString;
        } catch (e) {
            return '';
        }
    };
    const parseSpecificationString = (specString)=>{
        if (!specString || !specString.trim()) return [];
        try {
            // If it's already JSON format
            if (specString.startsWith('[') && specString.endsWith(']')) {
                const parsed = JSON.parse(specString);
                return Array.isArray(parsed) ? parsed : [];
            }
            // Parse comma-separated key:value pairs
            const specs = [];
            const pairs = specString.split(', ');
            for(let i = 0; i < pairs.length; i++){
                const pair = pairs[i];
                if (pair.includes(':')) {
                    const [key, ...valueParts] = pair.split(':');
                    const value = valueParts.join(':'); // Handle values with colons
                    specs.push({
                        id: Date.now().toString() + i,
                        name: key.trim(),
                        value: value.trim(),
                        displayOrder: i + 1
                    });
                }
            }
            return specs;
        } catch (error) {
            console.error('Error parsing specifications:', error);
            return [];
        }
    };
    // ✅ Add these new states
    const [isDeletingImage, setIsDeletingImage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [uploadingImages, setUploadingImages] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    // Dynamic dropdown data from API
    const [dropdownsData, setDropdownsData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        brands: [],
        categories: [],
        manufacturers: []
    });
    // Available products for related/cross-sell (from API)
    const [availableProducts, setAvailableProducts] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [formData, setFormData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        // Basic Info
        name: '',
        shortDescription: '',
        fullDescription: '',
        sku: '',
        brand: '',
        categories: '',
        manufacturerId: '',
        published: true,
        productType: 'simple',
        visibleIndividually: true,
        customerRoles: 'all',
        limitedToStores: false,
        vendorId: '',
        requireOtherProducts: false,
        requiredProductIds: '',
        automaticallyAddProducts: false,
        showOnHomepage: false,
        displayOrder: '1',
        productTags: '',
        gtin: '',
        manufacturerPartNumber: '',
        adminComment: '',
        allowCustomerReviews: false,
        // Related Products
        relatedProducts: [],
        crossSellProducts: [],
        // New fields for additional tabs
        productImages: [],
        videoUrls: [],
        specifications: [],
        // Pricing
        price: '',
        oldPrice: '',
        cost: '',
        disableBuyButton: false,
        disableWishlistButton: false,
        preOrderAvailabilityStartDate: '',
        callForPrice: false,
        customerEntersPrice: false,
        minimumCustomerEnteredPrice: '',
        maximumCustomerEnteredPrice: '',
        basepriceEnabled: false,
        basepriceAmount: '',
        basepriceUnit: '',
        basepriceBaseAmount: '',
        basepriceBaseUnit: '',
        markAsNew: false,
        markAsNewStartDate: '',
        markAsNewEndDate: '',
        categoryName: '',
        // Discounts
        hasDiscountsApplied: false,
        availableStartDate: '',
        availableEndDate: '',
        // Tax
        taxExempt: false,
        taxCategoryId: '',
        telecommunicationsBroadcastingElectronicServices: false,
        // SEO
        metaTitle: '',
        metaKeywords: '',
        metaDescription: '',
        searchEngineFriendlyPageName: '',
        // Inventory
        manageInventory: 'track',
        stockQuantity: '',
        displayStockAvailability: true,
        displayStockQuantity: false,
        minStockQuantity: '',
        lowStockActivity: 'nothing',
        notifyAdminForQuantityBelow: '',
        backorders: 'no-backorders',
        allowBackInStockSubscriptions: false,
        productAvailabilityRange: '',
        minCartQuantity: '1',
        maxCartQuantity: '10000',
        allowedQuantities: '',
        allowAddingOnlyExistingAttributeCombinations: false,
        notReturnable: false,
        // Shipping
        isShipEnabled: true,
        isFreeShipping: false,
        shipSeparately: false,
        additionalShippingCharge: '',
        deliveryDateId: '',
        weight: '',
        length: '',
        width: '',
        height: '',
        // Gift Cards
        isGiftCard: false,
        giftCardType: 'virtual',
        overriddenGiftCardAmount: '',
        // Downloadable Product
        isDownload: false,
        downloadId: '',
        unlimitedDownloads: true,
        maxNumberOfDownloads: '',
        downloadExpirationDays: '',
        downloadActivationType: 'when-order-is-paid',
        hasUserAgreement: false,
        userAgreementText: '',
        hasSampleDownload: false,
        sampleDownloadId: '',
        // Recurring Product
        isRecurring: false,
        recurringCycleLength: '',
        recurringCyclePeriod: 'days',
        recurringTotalCycles: '',
        // Rental Product
        isRental: false,
        rentalPriceLength: '',
        rentalPricePeriod: 'days'
    });
    // Clean renderCategoryOptions - no symbols, just clean hierarchy
    const renderCategoryOptions = (categories)=>{
        const options = [];
        categories.forEach((category)=>{
            // Add parent category (clean, no symbols)
            options.push(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                value: category.id,
                "data-category-name": category.name,
                "data-display-name": category.name,
                className: "font-semibold bg-slate-700 text-violet-300",
                style: {
                    fontWeight: 'bold',
                    backgroundColor: '#374151',
                    color: '#c4b5fd',
                    paddingLeft: '8px'
                },
                children: category.name
            }, category.id, false, {
                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                lineNumber: 334,
                columnNumber: 7
            }, this));
            // Add subcategories with >> format (clean display)
            if (category.subCategories && category.subCategories.length > 0) {
                category.subCategories.forEach((subCategory)=>{
                    const hierarchicalName = "".concat(category.name, " >> ").concat(subCategory.name);
                    options.push(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                        value: subCategory.id,
                        "data-category-name": hierarchicalName,
                        "data-parent-name": category.name,
                        "data-sub-name": subCategory.name,
                        "data-display-name": hierarchicalName,
                        className: "bg-slate-600 text-slate-300",
                        style: {
                            backgroundColor: '#4b5563',
                            color: '#d1d5db',
                            paddingLeft: '24px',
                            fontStyle: 'italic'
                        },
                        children: hierarchicalName
                    }, subCategory.id, false, {
                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                        lineNumber: 356,
                        columnNumber: 11
                    }, this));
                });
            }
        });
        return options;
    };
    // Combined useEffect to fetch all data
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "EditProductPage.useEffect": ()=>{
            const fetchAllData = {
                "EditProductPage.useEffect.fetchAllData": async ()=>{
                    try {
                        var _this, _this1, _this2;
                        console.log('🔄 Fetching all data (dropdowns + products + product details)...');
                        // Fetch dropdowns and products in parallel
                        const [brandsResponse, categoriesResponse, manufacturersResponse, productsResponse, productResponse] = await Promise.all([
                            __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiClient"].get('/api/Brands?includeUnpublished=false'),
                            __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiClient"].get('/api/Categories?includeInactive=true&includeSubCategories=true'),
                            __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiClient"].get('/api/Manufacturers'),
                            __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiClient"].get('/api/Products'),
                            __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiClient"].get("/api/Products/".concat(productId))
                        ]);
                        // Extract dropdown data
                        const brandsData = ((_this = brandsResponse.data) === null || _this === void 0 ? void 0 : _this.data) || [];
                        const categoriesData = ((_this1 = categoriesResponse.data) === null || _this1 === void 0 ? void 0 : _this1.data) || [];
                        const manufacturersData = ((_this2 = manufacturersResponse.data) === null || _this2 === void 0 ? void 0 : _this2.data) || [];
                        // Set dropdown data
                        setDropdownsData({
                            brands: brandsData,
                            categories: categoriesData,
                            manufacturers: manufacturersData
                        });
                        // Extract and transform products data for related/cross-sell
                        if (productsResponse.data && !productsResponse.error) {
                            const apiResponse = productsResponse.data;
                            if (apiResponse.success && apiResponse.data.items) {
                                const transformedProducts = apiResponse.data.items.map({
                                    "EditProductPage.useEffect.fetchAllData.transformedProducts": (product)=>({
                                            id: product.id,
                                            name: product.name,
                                            sku: product.sku,
                                            price: "₹".concat(product.price.toFixed(2))
                                        })
                                }["EditProductPage.useEffect.fetchAllData.transformedProducts"]);
                                setAvailableProducts(transformedProducts);
                            }
                        }
                        // Extract and populate product details
                        if (productResponse.data && !productResponse.error) {
                            const productApiResponse = productResponse.data;
                            if (productApiResponse.success && productApiResponse.data) {
                                const product = productApiResponse.data;
                                // 🎯 Helper function to get category display name
                                const getCategoryDisplayName = {
                                    "EditProductPage.useEffect.fetchAllData.getCategoryDisplayName": (categoryId, categories)=>{
                                        if (!categoryId) return '';
                                        for (const cat of categories){
                                            if (cat.id === categoryId) {
                                                return cat.name; // Parent category
                                            }
                                            if (cat.subCategories) {
                                                for (const sub of cat.subCategories){
                                                    if (sub.id === categoryId) {
                                                        return "".concat(cat.name, " >> ").concat(sub.name); // Subcategory with hierarchy
                                                    }
                                                }
                                            }
                                        }
                                        return '';
                                    }
                                }["EditProductPage.useEffect.fetchAllData.getCategoryDisplayName"];
                                // Get the category display name
                                const categoryDisplayName = getCategoryDisplayName(product.categoryId || '', categoriesData);
                                // Populate form with product data
                                // Replace your existing setFormData section in useEffect with this:
                                // REPLACE your existing setFormData section in useEffect with this COMPLETE VERSION:
                                setFormData({
                                    "EditProductPage.useEffect.fetchAllData": (prevData)=>{
                                        var _product_displayOrder, _product_price, _product_oldPrice, _product_compareAtPrice, _product_costPrice, _product_stockQuantity, _product_minStockQuantity, _product_weight, _product_length, _product_width, _product_height, _product_images;
                                        var _product_isPublished, _product_visibleIndividually, _product_showOnHomepage, _product_allowCustomerReviews, _product_requiresShipping;
                                        return {
                                            ...prevData,
                                            // Basic Info
                                            name: product.name || '',
                                            shortDescription: product.shortDescription || '',
                                            fullDescription: product.description || '',
                                            sku: product.sku || '',
                                            brand: product.brandId || '',
                                            categories: product.categoryId || '',
                                            categoryName: categoryDisplayName,
                                            manufacturerId: product.manufacturerId || '',
                                            published: (_product_isPublished = product.isPublished) !== null && _product_isPublished !== void 0 ? _product_isPublished : true,
                                            productType: product.productType || 'simple',
                                            visibleIndividually: (_product_visibleIndividually = product.visibleIndividually) !== null && _product_visibleIndividually !== void 0 ? _product_visibleIndividually : true,
                                            showOnHomepage: (_product_showOnHomepage = product.showOnHomepage) !== null && _product_showOnHomepage !== void 0 ? _product_showOnHomepage : false,
                                            displayOrder: ((_product_displayOrder = product.displayOrder) === null || _product_displayOrder === void 0 ? void 0 : _product_displayOrder.toString()) || '1',
                                            productTags: product.tags || '',
                                            gtin: product.gtin || '',
                                            manufacturerPartNumber: product.manufacturerPartNumber || '',
                                            // ✅ FIXED - Admin Comment
                                            adminComment: product.adminComment || '',
                                            // ✅ FIXED - Customer Reviews (add this field)
                                            allowCustomerReviews: (_product_allowCustomerReviews = product.allowCustomerReviews) !== null && _product_allowCustomerReviews !== void 0 ? _product_allowCustomerReviews : false,
                                            // Pricing
                                            price: ((_product_price = product.price) === null || _product_price === void 0 ? void 0 : _product_price.toString()) || '',
                                            oldPrice: ((_product_oldPrice = product.oldPrice) === null || _product_oldPrice === void 0 ? void 0 : _product_oldPrice.toString()) || ((_product_compareAtPrice = product.compareAtPrice) === null || _product_compareAtPrice === void 0 ? void 0 : _product_compareAtPrice.toString()) || '',
                                            cost: ((_product_costPrice = product.costPrice) === null || _product_costPrice === void 0 ? void 0 : _product_costPrice.toString()) || '',
                                            // ✅ FIXED - Availability Dates with proper formatting
                                            availableStartDate: formatDateTimeForInput(product.availableStartDate),
                                            availableEndDate: formatDateTimeForInput(product.availableEndDate),
                                            // ✅ FIXED - Pre-order date
                                            preOrderAvailabilityStartDate: formatDateTimeForInput(product.preOrderAvailabilityStartDate),
                                            // ✅ FIXED - Mark as New Dates  
                                            markAsNewStartDate: formatDateTimeForInput(product.markAsNewStartDate),
                                            markAsNewEndDate: formatDateTimeForInput(product.markAsNewEndDate),
                                            markAsNew: !!(product.markAsNewStartDate || product.markAsNewEndDate),
                                            // Inventory
                                            stockQuantity: ((_product_stockQuantity = product.stockQuantity) === null || _product_stockQuantity === void 0 ? void 0 : _product_stockQuantity.toString()) || '0',
                                            manageInventory: product.trackQuantity ? 'track' : 'dont-track',
                                            minStockQuantity: ((_product_minStockQuantity = product.minStockQuantity) === null || _product_minStockQuantity === void 0 ? void 0 : _product_minStockQuantity.toString()) || '0',
                                            // Shipping
                                            weight: ((_product_weight = product.weight) === null || _product_weight === void 0 ? void 0 : _product_weight.toString()) || '',
                                            length: ((_product_length = product.length) === null || _product_length === void 0 ? void 0 : _product_length.toString()) || '',
                                            width: ((_product_width = product.width) === null || _product_width === void 0 ? void 0 : _product_width.toString()) || '',
                                            height: ((_product_height = product.height) === null || _product_height === void 0 ? void 0 : _product_height.toString()) || '',
                                            isShipEnabled: (_product_requiresShipping = product.requiresShipping) !== null && _product_requiresShipping !== void 0 ? _product_requiresShipping : true,
                                            // SEO
                                            metaTitle: product.metaTitle || '',
                                            metaDescription: product.metaDescription || '',
                                            metaKeywords: product.metaKeywords || '',
                                            searchEngineFriendlyPageName: product.searchEngineFriendlyPageName || '',
                                            // Related Products
                                            relatedProducts: typeof product.relatedProductIds === 'string' ? product.relatedProductIds.split(',').filter({
                                                "EditProductPage.useEffect.fetchAllData": (id)=>id.trim()
                                            }["EditProductPage.useEffect.fetchAllData"]) : Array.isArray(product.relatedProductIds) ? product.relatedProductIds : [],
                                            crossSellProducts: typeof product.crossSellProductIds === 'string' ? product.crossSellProductIds.split(',').filter({
                                                "EditProductPage.useEffect.fetchAllData": (id)=>id.trim()
                                            }["EditProductPage.useEffect.fetchAllData"]) : Array.isArray(product.crossSellProductIds) ? product.crossSellProductIds : [],
                                            // Video URLs
                                            videoUrls: typeof product.videoUrls === 'string' ? product.videoUrls.split(',').filter({
                                                "EditProductPage.useEffect.fetchAllData": (url)=>url.trim()
                                            }["EditProductPage.useEffect.fetchAllData"]) : Array.isArray(product.videoUrls) ? product.videoUrls : [],
                                            // Product Images
                                            productImages: ((_product_images = product.images) === null || _product_images === void 0 ? void 0 : _product_images.map({
                                                "EditProductPage.useEffect.fetchAllData": (img)=>({
                                                        id: img.id || Date.now().toString(),
                                                        imageUrl: img.imageUrl || '',
                                                        altText: img.altText || '',
                                                        sortOrder: img.sortOrder || 1,
                                                        isMain: img.isMain || false,
                                                        fileName: img.imageUrl ? img.imageUrl.split('/').pop() : undefined,
                                                        fileSize: undefined,
                                                        file: undefined
                                                    })
                                            }["EditProductPage.useEffect.fetchAllData"])) || [],
                                            // ✅ COMPLETELY FIXED - Specifications parsing
                                            specifications: parseSpecificationString(product.specificationAttributes)
                                        };
                                    }
                                }["EditProductPage.useEffect.fetchAllData"]);
                                // ✅ COMPLETELY FIXED - Set attributes from API if they exist
                                if (product.attributes && Array.isArray(product.attributes)) {
                                    setAttributes(product.attributes.map({
                                        "EditProductPage.useEffect.fetchAllData": (attr)=>({
                                                id: attr.id || Date.now().toString(),
                                                name: attr.name || '',
                                                values: Array.isArray(attr.values) ? attr.values : typeof attr.values === 'string' ? attr.values.split(',').map({
                                                    "EditProductPage.useEffect.fetchAllData": (v)=>v.trim()
                                                }["EditProductPage.useEffect.fetchAllData"]) : [
                                                    ''
                                                ]
                                            })
                                    }["EditProductPage.useEffect.fetchAllData"]));
                                } else {
                                    // If no attributes in API, reset to empty
                                    setAttributes([]);
                                }
                            }
                        }
                    } catch (error) {
                        console.error('❌ Error fetching data:', error);
                        alert('Error loading data');
                    }
                }
            }["EditProductPage.useEffect.fetchAllData"];
            if (productId) {
                fetchAllData();
            }
        }
    }["EditProductPage.useEffect"], [
        productId
    ]);
    const handleSubmit = async function(e) {
        let isDraft = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : false;
        e.preventDefault();
        const target = e.target;
        if (target.hasAttribute('data-submitting')) {
            toast.info('⏳ Already submitting... Please wait!');
            return;
        }
        target.setAttribute('data-submitting', 'true');
        try {
            var _formData_shortDescription, _formData_gtin, _formData_manufacturerPartNumber, _formData_adminComment, _formData_metaTitle, _formData_metaDescription, _formData_metaKeywords, _formData_searchEngineFriendlyPageName, _formData_productTags;
            if (!formData.name || !formData.sku) {
                toast.error('⚠️ Please fill in required fields: Product Name and SKU');
                return;
            }
            const guidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
            let categoryId = null;
            if (formData.categories && formData.categories.trim()) {
                const trimmedCategory = formData.categories.trim();
                if (guidRegex.test(trimmedCategory)) {
                    categoryId = trimmedCategory;
                }
            }
            const formattedAttributes = attributes.filter((attr)=>attr.name && attr.name.trim()).map((attr)=>{
                const filteredValues = attr.values.filter((value)=>value && value.trim()).map((value)=>value.trim());
                return {
                    id: attr.id,
                    name: attr.name.trim(),
                    values: filteredValues
                };
            }).filter((attr)=>attr.values.length > 0);
            let brandId = null;
            if (formData.brand && formData.brand.trim()) {
                const trimmedBrand = formData.brand.trim();
                if (guidRegex.test(trimmedBrand)) {
                    brandId = trimmedBrand;
                }
            }
            let manufacturerId = null;
            if (formData.manufacturerId && formData.manufacturerId.trim()) {
                const trimmedManufacturer = formData.manufacturerId.trim();
                if (guidRegex.test(trimmedManufacturer)) {
                    manufacturerId = trimmedManufacturer;
                }
            }
            // ✅ Don't trim/reduce description - send as-is
            const productData = {
                id: productId,
                name: formData.name.trim(),
                description: formData.fullDescription || formData.shortDescription || formData.name || 'Product description',
                shortDescription: ((_formData_shortDescription = formData.shortDescription) === null || _formData_shortDescription === void 0 ? void 0 : _formData_shortDescription.trim()) || '',
                sku: formData.sku.trim(),
                gtin: ((_formData_gtin = formData.gtin) === null || _formData_gtin === void 0 ? void 0 : _formData_gtin.trim()) || null,
                manufacturerPartNumber: ((_formData_manufacturerPartNumber = formData.manufacturerPartNumber) === null || _formData_manufacturerPartNumber === void 0 ? void 0 : _formData_manufacturerPartNumber.trim()) || null,
                displayOrder: parseInt(formData.displayOrder) || 1,
                adminComment: ((_formData_adminComment = formData.adminComment) === null || _formData_adminComment === void 0 ? void 0 : _formData_adminComment.trim()) || null,
                price: parseFloat(formData.price) || 0,
                oldPrice: formData.oldPrice ? parseFloat(formData.oldPrice) : null,
                compareAtPrice: formData.oldPrice ? parseFloat(formData.oldPrice) : null,
                costPrice: formData.cost ? parseFloat(formData.cost) : null,
                attributes: formattedAttributes,
                weight: parseFloat(formData.weight) || 0,
                length: formData.length ? parseFloat(formData.length) : null,
                width: formData.width ? parseFloat(formData.width) : null,
                height: formData.height ? parseFloat(formData.height) : null,
                requiresShipping: formData.isShipEnabled,
                stockQuantity: parseInt(formData.stockQuantity) || 0,
                trackQuantity: formData.manageInventory === 'track',
                ...categoryId && {
                    categoryId
                },
                ...brandId && {
                    brandId
                },
                ...manufacturerId && {
                    manufacturerId
                },
                availableStartDate: formData.availableStartDate ? new Date(formData.availableStartDate).toISOString() : null,
                availableEndDate: formData.availableEndDate ? new Date(formData.availableEndDate).toISOString() : null,
                markAsNewStartDate: formData.markAsNewStartDate ? new Date(formData.markAsNewStartDate).toISOString() : null,
                markAsNewEndDate: formData.markAsNewEndDate ? new Date(formData.markAsNewEndDate).toISOString() : null,
                preOrderAvailabilityStartDate: formData.preOrderAvailabilityStartDate ? new Date(formData.preOrderAvailabilityStartDate).toISOString() : null,
                specificationAttributes: formData.specifications.length > 0 ? JSON.stringify(formData.specifications) : null,
                isPublished: isDraft ? false : formData.published,
                status: isDraft ? 1 : formData.published ? 2 : 1,
                visibleIndividually: formData.visibleIndividually,
                showOnHomepage: formData.showOnHomepage || false,
                metaTitle: ((_formData_metaTitle = formData.metaTitle) === null || _formData_metaTitle === void 0 ? void 0 : _formData_metaTitle.trim()) || null,
                metaDescription: ((_formData_metaDescription = formData.metaDescription) === null || _formData_metaDescription === void 0 ? void 0 : _formData_metaDescription.trim()) || null,
                metaKeywords: ((_formData_metaKeywords = formData.metaKeywords) === null || _formData_metaKeywords === void 0 ? void 0 : _formData_metaKeywords.trim()) || null,
                searchEngineFriendlyPageName: ((_formData_searchEngineFriendlyPageName = formData.searchEngineFriendlyPageName) === null || _formData_searchEngineFriendlyPageName === void 0 ? void 0 : _formData_searchEngineFriendlyPageName.trim()) || null,
                tags: ((_formData_productTags = formData.productTags) === null || _formData_productTags === void 0 ? void 0 : _formData_productTags.trim()) || null,
                relatedProductIds: Array.isArray(formData.relatedProducts) && formData.relatedProducts.length > 0 ? formData.relatedProducts.join(',') : null,
                crossSellProductIds: Array.isArray(formData.crossSellProducts) && formData.crossSellProducts.length > 0 ? formData.crossSellProducts.join(',') : null,
                videoUrls: formData.videoUrls && formData.videoUrls.length > 0 ? formData.videoUrls.join(',') : null
            };
            // Log size
            const payloadSize = new Blob([
                JSON.stringify(productData)
            ]).size;
            console.log("📦 Payload size: ".concat((payloadSize / 1024).toFixed(2), " KB"));
            // Call API
            const response = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiClient"].put("/api/Products/".concat(productId), productData);
            if (response === null || response === void 0 ? void 0 : response.data) {
                const message = isDraft ? '💾 Product saved as draft successfully!' : '✅ Product updated successfully!';
                toast.success(message, {
                    autoClose: 5000,
                    closeButton: true,
                    draggable: true
                });
                setTimeout(()=>{
                    router.push('/admin/products');
                }, 800);
            } else if (response === null || response === void 0 ? void 0 : response.error) {
                throw new Error(response.error);
            }
        } catch (error) {
            var _error_response;
            console.error('❌ Error submitting form:', error);
            let errorMessage = 'Failed to update product';
            if ((_error_response = error.response) === null || _error_response === void 0 ? void 0 : _error_response.data) {
                const errorData = error.response.data;
                if (errorData === null || errorData === void 0 ? void 0 : errorData.errors) {
                    let details = '';
                    for (const [field, messages] of Object.entries(errorData.errors)){
                        const fieldName = field.replace('$', '').replace('.', ' ').trim();
                        const msg = Array.isArray(messages) ? messages.join(', ') : messages;
                        details += "• ".concat(fieldName, ": ").concat(msg, "\n");
                    }
                    errorMessage = "Validation Failed:\n".concat(details);
                } else if (errorData === null || errorData === void 0 ? void 0 : errorData.message) {
                    errorMessage = errorData.message;
                } else if (errorData === null || errorData === void 0 ? void 0 : errorData.title) {
                    errorMessage = errorData.title;
                }
            } else if (error.message) {
                errorMessage = error.message;
            }
            toast.error(errorMessage, {
                autoClose: 8000,
                closeButton: true,
                draggable: true
            });
        } finally{
            target.removeAttribute('data-submitting');
        }
    };
    // Updated handleChange to extract clean hierarchical names
    const handleChange = (e)=>{
        const { name, value, type } = e.target;
        // Special handling for category selection
        if (name === 'categories') {
            const selectElement = e.target;
            const selectedOption = selectElement.options[selectElement.selectedIndex];
            let displayName = '';
            if (value === '') {
                displayName = '';
            } else {
                // Get the clean hierarchical display name
                displayName = selectedOption.dataset.categoryName || selectedOption.dataset.displayName || selectedOption.text.replace(/^[\s\u00A0]*└──\s*/, '').replace(/📁\s*/, '');
            }
            setFormData({
                ...formData,
                [name]: value,
                categoryName: displayName // Store clean display name
            });
        } else {
            setFormData({
                ...formData,
                [name]: type === 'checkbox' ? e.target.checked : value
            });
        }
    };
    // All existing methods remain same...
    const addRelatedProduct = (productId)=>{
        if (!formData.relatedProducts.includes(productId)) {
            setFormData({
                ...formData,
                relatedProducts: [
                    ...formData.relatedProducts,
                    productId
                ]
            });
        }
        setSearchTerm('');
    };
    const removeRelatedProduct = (productId)=>{
        setFormData({
            ...formData,
            relatedProducts: formData.relatedProducts.filter((id)=>id !== productId)
        });
    };
    const addCrossSellProduct = (productId)=>{
        if (!formData.crossSellProducts.includes(productId)) {
            setFormData({
                ...formData,
                crossSellProducts: [
                    ...formData.crossSellProducts,
                    productId
                ]
            });
        }
        setSearchTermCross('');
    };
    const removeCrossSellProduct = (productId)=>{
        setFormData({
            ...formData,
            crossSellProducts: formData.crossSellProducts.filter((id)=>id !== productId)
        });
    };
    const filteredProducts = availableProducts.filter((p)=>p.name.toLowerCase().includes(searchTerm.toLowerCase()) || p.sku.toLowerCase().includes(searchTerm.toLowerCase()));
    const filteredProductsCross = availableProducts.filter((p)=>p.name.toLowerCase().includes(searchTermCross.toLowerCase()) || p.sku.toLowerCase().includes(searchTermCross.toLowerCase()));
    // ✅ REPLACE your existing addAttribute function
    const addAttribute = ()=>{
        const newAttribute = {
            id: Date.now().toString() + Math.random().toString(36),
            name: '',
            values: [
                ''
            ] // Start with one empty value
        };
        setAttributes((prevAttributes)=>[
                ...prevAttributes,
                newAttribute
            ]);
        // Optional: Auto-focus on the new attribute name field
        setTimeout(()=>{
            const newInput = document.querySelector('input[data-attr-id="'.concat(newAttribute.id, '"]'));
            if (newInput) newInput.focus();
        }, 100);
    };
    // ✅ REPLACE existing functions with these improved versions
    const removeAttribute = (id)=>{
        setAttributes((prevAttributes)=>prevAttributes.filter((attr)=>attr.id !== id));
    };
    const updateAttributeName = (id, name)=>{
        setAttributes((prevAttributes)=>prevAttributes.map((attr)=>attr.id === id ? {
                    ...attr,
                    name
                } : attr));
    };
    const updateAttributeValue = (attrId, valueIndex, value)=>{
        setAttributes((prevAttributes)=>prevAttributes.map((attr)=>{
                if (attr.id === attrId) {
                    const newValues = [
                        ...attr.values
                    ];
                    newValues[valueIndex] = value;
                    return {
                        ...attr,
                        values: newValues
                    };
                }
                return attr;
            }));
    };
    const addAttributeValue = (attrId)=>{
        setAttributes((prevAttributes)=>prevAttributes.map((attr)=>{
                if (attr.id === attrId) {
                    return {
                        ...attr,
                        values: [
                            ...attr.values,
                            ''
                        ]
                    };
                }
                return attr;
            }));
    };
    const removeAttributeValue = (attrId, valueIndex)=>{
        setAttributes((prevAttributes)=>prevAttributes.map((attr)=>{
                if (attr.id === attrId && attr.values.length > 1) {
                    return {
                        ...attr,
                        values: attr.values.filter((_, idx)=>idx !== valueIndex)
                    };
                }
                return attr;
            }));
    };
    // ✅ REPLACE existing handleImageUpload function:
    const handleImageUpload = async (e)=>{
        const files = e.target.files;
        if (!files || files.length === 0) return;
        if (!formData.name.trim()) {
            toast.error("Please enter product name before uploading images");
            return;
        }
        if (formData.productImages.length + files.length > 10) {
            toast.error("Maximum 10 images allowed. You can add ".concat(10 - formData.productImages.length, " more."));
            return;
        }
        setUploadingImages(true);
        try {
            // Since we have productId, upload directly to the product
            const uploadedImages = await uploadImagesToProductDirect(productId, Array.from(files));
            // Add uploaded images to existing images
            const newImages = uploadedImages.map((img)=>({
                    id: img.id,
                    imageUrl: img.imageUrl,
                    altText: img.altText,
                    sortOrder: img.sortOrder,
                    isMain: img.isMain,
                    fileName: img.imageUrl.split('/').pop() || '',
                    fileSize: 0,
                    file: undefined
                }));
            setFormData((prev)=>({
                    ...prev,
                    productImages: [
                        ...prev.productImages,
                        ...newImages
                    ]
                }));
            toast.success("".concat(uploadedImages.length, " image(s) uploaded successfully! 📷"));
            if (fileInputRef.current) {
                fileInputRef.current.value = '';
            }
        } catch (error) {
            console.error('Error processing images:', error);
            toast.error('Failed to process images. Please try again.');
        } finally{
            setUploadingImages(false);
        }
    };
    const handleBrowseClick = ()=>{
        var _fileInputRef_current;
        (_fileInputRef_current = fileInputRef.current) === null || _fileInputRef_current === void 0 ? void 0 : _fileInputRef_current.click();
    };
    // ✅ REPLACE existing removeImage function with this:
    const removeImage = async (imageId)=>{
        const imageToRemove = formData.productImages.find((img)=>img.id === imageId);
        if (!imageToRemove) return;
        // If it's a blob URL (newly uploaded), just remove from state
        if (imageToRemove.imageUrl.startsWith('blob:')) {
            URL.revokeObjectURL(imageToRemove.imageUrl);
            setFormData({
                ...formData,
                productImages: formData.productImages.filter((img)=>img.id !== imageId)
            });
            return;
        }
        // If it's an existing image from database, call delete API
        setIsDeletingImage(true);
        try {
            const token = localStorage.getItem('authToken');
            const deleteResponse = await fetch("".concat(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2d$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["API_BASE_URL"], "/api/Products/images/").concat(imageId), {
                method: 'DELETE',
                headers: {
                    ...token && {
                        'Authorization': "Bearer ".concat(token)
                    }
                }
            });
            if (deleteResponse.ok) {
                toast.success('Image deleted successfully! 🗑️');
                setFormData({
                    ...formData,
                    productImages: formData.productImages.filter((img)=>img.id !== imageId)
                });
            } else {
                const errorData = await deleteResponse.json().catch(()=>({
                        message: 'Failed to delete image'
                    }));
                throw new Error(errorData.message || 'Failed to delete image');
            }
        } catch (error) {
            console.error('Error deleting image:', error);
            toast.error("Failed to delete image: ".concat(error.message));
        } finally{
            setIsDeletingImage(false);
        }
    };
    // ✅ ADD this new function:
    const uploadImagesToProductDirect = async (productId, files)=>{
        const uploadPromises = files.map(async (file, index)=>{
            try {
                const uploadFormData = new FormData();
                uploadFormData.append('images', file);
                uploadFormData.append('altText', file.name.replace(/\.[^/.]+$/, ""));
                uploadFormData.append('sortOrder', (formData.productImages.length + index + 1).toString());
                uploadFormData.append('isMain', (formData.productImages.length === 0 && index === 0).toString());
                const token = localStorage.getItem('authToken');
                const uploadResponse = await fetch("".concat(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2d$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["API_BASE_URL"], "/api/Products/").concat(productId, "/images?name=").concat(encodeURIComponent(formData.name)), {
                    method: 'POST',
                    headers: {
                        ...token && {
                            'Authorization': "Bearer ".concat(token)
                        }
                    },
                    body: uploadFormData
                });
                if (uploadResponse.ok) {
                    const result = await uploadResponse.json();
                    if (result && result.success && result.data) {
                        return Array.isArray(result.data) ? result.data[0] : result.data;
                    }
                }
                throw new Error("Upload failed for ".concat(file.name));
            } catch (error) {
                console.error("Error uploading ".concat(file.name, ":"), error);
                toast.error("Failed to upload ".concat(file.name));
                return null;
            }
        });
        const results = await Promise.all(uploadPromises);
        return results.filter((result)=>result !== null);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "space-y-2",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-slate-900/50 backdrop-blur-xl border border-slate-800 rounded-2xl p-2",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center gap-4",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    href: "/admin/products",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        className: "p-2.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition-all",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$left$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowLeft$3e$__["ArrowLeft"], {
                                            className: "h-5 w-5"
                                        }, void 0, false, {
                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                            lineNumber: 1070,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                        lineNumber: 1069,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                    lineNumber: 1068,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                            className: "text-3xl font-bold tracking-tight bg-gradient-to-r from-violet-400 via-cyan-400 to-pink-400 bg-clip-text text-transparent",
                                            children: "Edit Product"
                                        }, void 0, false, {
                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                            lineNumber: 1074,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-sm text-slate-400 mt-1",
                                            children: "Update and configure your product details"
                                        }, void 0, false, {
                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                            lineNumber: 1077,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                    lineNumber: 1073,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                            lineNumber: 1067,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center gap-3",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: ()=>router.push('/admin/products'),
                                    className: "px-5 py-2.5 bg-slate-800/50 border border-slate-700 rounded-xl text-slate-300 hover:bg-slate-800 hover:border-slate-600 transition-all text-sm font-medium",
                                    children: "Cancel"
                                }, void 0, false, {
                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                    lineNumber: 1081,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    onClick: (e)=>handleSubmit(e, true),
                                    className: "px-4 py-2 rounded-xl bg-orange-500/10 border border-orange-500/30 text-orange-400 hover:bg-orange-500/20 hover:border-orange-500/50 transition-all text-sm font-medium flex items-center gap-2",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "w-2 h-2 bg-orange-400 rounded-full animate-pulse"
                                        }, void 0, false, {
                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                            lineNumber: 1092,
                                            columnNumber: 15
                                        }, this),
                                        "Save as Draft"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                    lineNumber: 1087,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    onClick: (e)=>handleSubmit(e, false),
                                    className: "px-5 py-2.5 bg-gradient-to-r from-violet-500 to-cyan-500 text-white rounded-xl hover:shadow-lg hover:shadow-violet-500/50 transition-all text-sm flex items-center gap-2 font-semibold",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$save$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Save$3e$__["Save"], {
                                            className: "h-4 w-4"
                                        }, void 0, false, {
                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                            lineNumber: 1100,
                                            columnNumber: 15
                                        }, this),
                                        "Update Product"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                    lineNumber: 1095,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                            lineNumber: 1080,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                    lineNumber: 1066,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                lineNumber: 1065,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "w-full",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "w-full",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "bg-slate-900/50 backdrop-blur-xl border border-slate-800 rounded-2xl p-2",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Tabs"], {
                            defaultValue: "product-info",
                            className: "w-full",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "border-b border-slate-800 mb-3",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TabsList"], {
                                        className: "flex gap-1 overflow-x-auto pb-px scrollbar-thin scrollbar-thumb-slate-700 scrollbar-track-transparent bg-transparent h-auto p-0",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TabsTrigger"], {
                                                value: "product-info",
                                                className: "flex items-center gap-2 px-4 py-2.5 text-sm font-medium text-slate-400 hover:text-violet-400 border-b-2 border-transparent data-[state=active]:border-violet-500 data-[state=active]:text-violet-400 data-[state=active]:bg-slate-800/50 whitespace-nowrap transition-all rounded-t-lg",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$info$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Info$3e$__["Info"], {
                                                        className: "h-4 w-4"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                        lineNumber: 1116,
                                                        columnNumber: 21
                                                    }, this),
                                                    "Product Info"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                lineNumber: 1115,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TabsTrigger"], {
                                                value: "prices",
                                                className: "flex items-center gap-2 px-4 py-2.5 text-sm font-medium text-slate-400 hover:text-violet-400 border-b-2 border-transparent data-[state=active]:border-violet-500 data-[state=active]:text-violet-400 data-[state=active]:bg-slate-800/50 whitespace-nowrap transition-all rounded-t-lg",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$dollar$2d$sign$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DollarSign$3e$__["DollarSign"], {
                                                        className: "h-4 w-4"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                        lineNumber: 1120,
                                                        columnNumber: 21
                                                    }, this),
                                                    "Prices"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                lineNumber: 1119,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TabsTrigger"], {
                                                value: "inventory",
                                                className: "flex items-center gap-2 px-4 py-2.5 text-sm font-medium text-slate-400 hover:text-violet-400 border-b-2 border-transparent data-[state=active]:border-violet-500 data-[state=active]:text-violet-400 data-[state=active]:bg-slate-800/50 whitespace-nowrap transition-all rounded-t-lg",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$package$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Package$3e$__["Package"], {
                                                        className: "h-4 w-4"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                        lineNumber: 1124,
                                                        columnNumber: 21
                                                    }, this),
                                                    "Inventory"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                lineNumber: 1123,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TabsTrigger"], {
                                                value: "shipping",
                                                className: "flex items-center gap-2 px-4 py-2.5 text-sm font-medium text-slate-400 hover:text-violet-400 border-b-2 border-transparent data-[state=active]:border-violet-500 data-[state=active]:text-violet-400 data-[state=active]:bg-slate-800/50 whitespace-nowrap transition-all rounded-t-lg",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$truck$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Truck$3e$__["Truck"], {
                                                        className: "h-4 w-4"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                        lineNumber: 1128,
                                                        columnNumber: 21
                                                    }, this),
                                                    "Shipping"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                lineNumber: 1127,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TabsTrigger"], {
                                                value: "related-products",
                                                className: "flex items-center gap-2 px-4 py-2.5 text-sm font-medium text-slate-400 hover:text-violet-400 border-b-2 border-transparent data-[state=active]:border-violet-500 data-[state=active]:text-violet-400 data-[state=active]:bg-slate-800/50 whitespace-nowrap transition-all rounded-t-lg",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Link$3e$__["Link"], {
                                                        className: "h-4 w-4"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                        lineNumber: 1132,
                                                        columnNumber: 21
                                                    }, this),
                                                    "Related"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                lineNumber: 1131,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TabsTrigger"], {
                                                value: "attributes",
                                                className: "flex items-center gap-2 px-4 py-2.5 text-sm font-medium text-slate-400 hover:text-violet-400 border-b-2 border-transparent data-[state=active]:border-violet-500 data-[state=active]:text-violet-400 data-[state=active]:bg-slate-800/50 whitespace-nowrap transition-all rounded-t-lg",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$tag$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tag$3e$__["Tag"], {
                                                        className: "h-4 w-4"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                        lineNumber: 1136,
                                                        columnNumber: 21
                                                    }, this),
                                                    "Attributes"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                lineNumber: 1135,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TabsTrigger"], {
                                                value: "seo",
                                                className: "flex items-center gap-2 px-4 py-2.5 text-sm font-medium text-slate-400 hover:text-violet-400 border-b-2 border-transparent data-[state=active]:border-violet-500 data-[state=active]:text-violet-400 data-[state=active]:bg-slate-800/50 whitespace-nowrap transition-all rounded-t-lg",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$globe$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Globe$3e$__["Globe"], {
                                                        className: "h-4 w-4"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                        lineNumber: 1140,
                                                        columnNumber: 21
                                                    }, this),
                                                    "SEO"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                lineNumber: 1139,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TabsTrigger"], {
                                                value: "pictures",
                                                className: "flex items-center gap-2 px-4 py-2.5 text-sm font-medium text-slate-400 hover:text-violet-400 border-b-2 border-transparent data-[state=active]:border-violet-500 data-[state=active]:text-violet-400 data-[state=active]:bg-slate-800/50 whitespace-nowrap transition-all rounded-t-lg",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Image$3e$__["Image"], {
                                                        className: "h-4 w-4"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                        lineNumber: 1144,
                                                        columnNumber: 21
                                                    }, this),
                                                    "Pictures"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                lineNumber: 1143,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TabsTrigger"], {
                                                value: "videos",
                                                className: "flex items-center gap-2 px-4 py-2.5 text-sm font-medium text-slate-400 hover:text-violet-400 border-b-2 border-transparent data-[state=active]:border-violet-500 data-[state=active]:text-violet-400 data-[state=active]:bg-slate-800/50 whitespace-nowrap transition-all rounded-t-lg",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$video$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Video$3e$__["Video"], {
                                                        className: "h-4 w-4"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                        lineNumber: 1148,
                                                        columnNumber: 21
                                                    }, this),
                                                    "Videos"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                lineNumber: 1147,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TabsTrigger"], {
                                                value: "specifications",
                                                className: "flex items-center gap-2 px-4 py-2.5 text-sm font-medium text-slate-400 hover:text-violet-400 border-b-2 border-transparent data-[state=active]:border-violet-500 data-[state=active]:text-violet-400 data-[state=active]:bg-slate-800/50 whitespace-nowrap transition-all rounded-t-lg",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chart$2d$column$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BarChart3$3e$__["BarChart3"], {
                                                        className: "h-4 w-4"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                        lineNumber: 1152,
                                                        columnNumber: 21
                                                    }, this),
                                                    "Specifications"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                lineNumber: 1151,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                        lineNumber: 1114,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                    lineNumber: 1113,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TabsContent"], {
                                    value: "product-info",
                                    className: "space-y-2 mt-2",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "space-y-4",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                    className: "text-lg font-semibold text-white border-b border-slate-800 pb-2",
                                                    children: "Basic Info"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                    lineNumber: 1162,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "grid gap-4",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                    className: "block text-sm font-medium text-slate-300 mb-2",
                                                                    children: [
                                                                        "Product Name ",
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                            className: "text-red-500",
                                                                            children: "*"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                            lineNumber: 1167,
                                                                            columnNumber: 38
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1166,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                    type: "text",
                                                                    name: "name",
                                                                    value: formData.name,
                                                                    onChange: handleChange,
                                                                    placeholder: "Enter product name",
                                                                    className: "w-full px-3 py-2 bg-slate-800/50 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:ring-2 focus:ring-violet-500 focus:border-transparent transition-all",
                                                                    required: true
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1169,
                                                                    columnNumber: 23
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                            lineNumber: 1165,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$admin$2f$products$2f$SelfHostedEditor$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ProductDescriptionEditor"], {
                                                            label: "Short Description",
                                                            value: formData.shortDescription,
                                                            onChange: (content)=>setFormData((prev)=>({
                                                                        ...prev,
                                                                        shortDescription: content
                                                                    })),
                                                            placeholder: "Enter product short description...",
                                                            height: 250
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                            lineNumber: 1182,
                                                            columnNumber: 1
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$admin$2f$products$2f$SelfHostedEditor$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ProductDescriptionEditor"], {
                                                            label: "Full Description",
                                                            value: formData.fullDescription,
                                                            onChange: (content)=>setFormData((prev)=>({
                                                                        ...prev,
                                                                        fullDescription: content
                                                                    })),
                                                            placeholder: "Enter detailed product description...",
                                                            height: 400,
                                                            required: true
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                            lineNumber: 1193,
                                                            columnNumber: 1
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "grid md:grid-cols-3 gap-4",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                            className: "block text-sm font-medium text-slate-300 mb-2",
                                                                            children: [
                                                                                "SKU ",
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                    className: "text-red-500",
                                                                                    children: "*"
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                                    lineNumber: 1210,
                                                                                    columnNumber: 31
                                                                                }, this)
                                                                            ]
                                                                        }, void 0, true, {
                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                            lineNumber: 1209,
                                                                            columnNumber: 25
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                            type: "text",
                                                                            name: "sku",
                                                                            value: formData.sku,
                                                                            onChange: handleChange,
                                                                            placeholder: "e.g., PROD-001",
                                                                            className: "w-full px-3 py-2 bg-slate-800/50 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:ring-2 focus:ring-violet-500 focus:border-transparent transition-all",
                                                                            required: true
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                            lineNumber: 1212,
                                                                            columnNumber: 25
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1208,
                                                                    columnNumber: 25
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                            className: "block text-sm font-medium text-slate-300 mb-2",
                                                                            children: "Brand  "
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                            lineNumber: 1226,
                                                                            columnNumber: 25
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                                                            name: "brand",
                                                                            value: formData.brand,
                                                                            onChange: handleChange,
                                                                            className: "w-full px-3 py-2 bg-slate-800/50 border border-slate-700 rounded-xl text-white focus:ring-2 focus:ring-violet-500 focus:border-transparent transition-all",
                                                                            children: [
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                                    value: "",
                                                                                    children: [
                                                                                        "Select brand (",
                                                                                        dropdownsData.brands.length,
                                                                                        ") "
                                                                                    ]
                                                                                }, void 0, true, {
                                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                                    lineNumber: 1233,
                                                                                    columnNumber: 27
                                                                                }, this),
                                                                                dropdownsData.brands.map((brand)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                                        value: brand.id,
                                                                                        children: brand.name
                                                                                    }, brand.id, false, {
                                                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                                        lineNumber: 1235,
                                                                                        columnNumber: 29
                                                                                    }, this))
                                                                            ]
                                                                        }, void 0, true, {
                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                            lineNumber: 1227,
                                                                            columnNumber: 25
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1225,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                            className: "block text-sm font-medium text-slate-300 mb-2",
                                                                            children: "Categories"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                            lineNumber: 1244,
                                                                            columnNumber: 3
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                            className: "relative",
                                                                            children: [
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                                                                    name: "categories",
                                                                                    value: formData.categories,
                                                                                    onChange: handleChange,
                                                                                    className: "w-full px-3 py-2 bg-slate-800/50 border border-slate-700 rounded-xl text-transparent focus:ring-2 focus:ring-violet-500 focus:border-transparent transition-all appearance-none cursor-pointer",
                                                                                    children: [
                                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                                            value: "",
                                                                                            className: "text-white",
                                                                                            title: "categories loaded (includes subcategories)",
                                                                                            children: [
                                                                                                "Select category (",
                                                                                                dropdownsData.categories.length,
                                                                                                ") "
                                                                                            ]
                                                                                        }, void 0, true, {
                                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                                            lineNumber: 1254,
                                                                                            columnNumber: 7
                                                                                        }, this),
                                                                                        renderCategoryOptions(dropdownsData.categories)
                                                                                    ]
                                                                                }, void 0, true, {
                                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                                    lineNumber: 1248,
                                                                                    columnNumber: 5
                                                                                }, this),
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                    className: "absolute inset-0 px-3 py-2 pointer-events-none flex items-center justify-between",
                                                                                    children: [
                                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                            className: "truncate text-sm ".concat(formData.categoryName ? 'text-white' : 'text-slate-400'),
                                                                                            children: formData.categoryName || 'Select category'
                                                                                        }, void 0, false, {
                                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                                            lineNumber: 1260,
                                                                                            columnNumber: 7
                                                                                        }, this),
                                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                                                            className: "w-4 h-4 text-slate-400 flex-shrink-0 ml-2",
                                                                                            fill: "none",
                                                                                            stroke: "currentColor",
                                                                                            viewBox: "0 0 24 24",
                                                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                                                strokeLinecap: "round",
                                                                                                strokeLinejoin: "round",
                                                                                                strokeWidth: 2,
                                                                                                d: "M19 9l-7 7-7-7"
                                                                                            }, void 0, false, {
                                                                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                                                lineNumber: 1266,
                                                                                                columnNumber: 9
                                                                                            }, this)
                                                                                        }, void 0, false, {
                                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                                            lineNumber: 1265,
                                                                                            columnNumber: 7
                                                                                        }, this)
                                                                                    ]
                                                                                }, void 0, true, {
                                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                                    lineNumber: 1259,
                                                                                    columnNumber: 5
                                                                                }, this)
                                                                            ]
                                                                        }, void 0, true, {
                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                            lineNumber: 1247,
                                                                            columnNumber: 3
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1243,
                                                                    columnNumber: 18
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                            lineNumber: 1206,
                                                            columnNumber: 22
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "grid md:grid-cols-2 gap-4",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                            className: "block text-sm font-medium text-slate-300 mb-2",
                                                                            children: "Manufacturer"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                            lineNumber: 1275,
                                                                            columnNumber: 25
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                                                            name: "manufacturerId",
                                                                            value: formData.manufacturerId,
                                                                            onChange: handleChange,
                                                                            className: "w-full px-3 py-2 bg-slate-800/50 border border-slate-700 rounded-xl text-white focus:ring-2 focus:ring-violet-500 focus:border-transparent transition-all",
                                                                            children: [
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                                    value: "",
                                                                                    children: "Select manufacturer"
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                                    lineNumber: 1282,
                                                                                    columnNumber: 27
                                                                                }, this),
                                                                                dropdownsData.manufacturers.map((manufacturer)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                                        value: manufacturer.id,
                                                                                        children: manufacturer.name
                                                                                    }, manufacturer.id, false, {
                                                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                                        lineNumber: 1284,
                                                                                        columnNumber: 29
                                                                                    }, this))
                                                                            ]
                                                                        }, void 0, true, {
                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                            lineNumber: 1276,
                                                                            columnNumber: 25
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                            className: "text-xs text-slate-400 mt-1",
                                                                            children: [
                                                                                dropdownsData.manufacturers.length,
                                                                                " manufacturers loaded"
                                                                            ]
                                                                        }, void 0, true, {
                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                            lineNumber: 1289,
                                                                            columnNumber: 25
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1274,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                            className: "block text-sm font-medium text-slate-300 mb-2",
                                                                            children: "Product Type"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                            lineNumber: 1295,
                                                                            columnNumber: 25
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                                                            name: "productType",
                                                                            value: formData.productType,
                                                                            onChange: handleChange,
                                                                            className: "w-full px-3 py-2 bg-slate-800/50 border border-slate-700 rounded-xl text-white focus:ring-2 focus:ring-violet-500 focus:border-transparent transition-all",
                                                                            children: [
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                                    value: "simple",
                                                                                    children: "Simple Product"
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                                    lineNumber: 1302,
                                                                                    columnNumber: 27
                                                                                }, this),
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                                    value: "grouped",
                                                                                    children: "Grouped Product (product variants)"
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                                    lineNumber: 1303,
                                                                                    columnNumber: 27
                                                                                }, this)
                                                                            ]
                                                                        }, void 0, true, {
                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                            lineNumber: 1296,
                                                                            columnNumber: 25
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1294,
                                                                    columnNumber: 23
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                            lineNumber: 1273,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "grid md:grid-cols-3 gap-4",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                            className: "block text-sm font-medium text-slate-300 mb-2",
                                                                            children: "GTIN"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                            lineNumber: 1311,
                                                                            columnNumber: 25
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                            type: "text",
                                                                            name: "gtin",
                                                                            value: formData.gtin,
                                                                            onChange: handleChange,
                                                                            placeholder: "Global Trade Item Number",
                                                                            className: "w-full px-3 py-2 bg-slate-800/50 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:ring-2 focus:ring-violet-500 focus:border-transparent transition-all"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                            lineNumber: 1312,
                                                                            columnNumber: 25
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1310,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                            className: "block text-sm font-medium text-slate-300 mb-2",
                                                                            children: "Manufacturer Part Number"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                            lineNumber: 1323,
                                                                            columnNumber: 25
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                            type: "text",
                                                                            name: "manufacturerPartNumber",
                                                                            value: formData.manufacturerPartNumber,
                                                                            onChange: handleChange,
                                                                            placeholder: "MPN",
                                                                            className: "w-full px-3 py-2 bg-slate-800/50 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:ring-2 focus:ring-violet-500 focus:border-transparent transition-all"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                            lineNumber: 1324,
                                                                            columnNumber: 25
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1322,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                            className: "block text-sm font-medium text-slate-300 mb-2",
                                                                            children: "Display Order"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                            lineNumber: 1335,
                                                                            columnNumber: 25
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                            type: "number",
                                                                            name: "displayOrder",
                                                                            value: formData.displayOrder,
                                                                            onChange: handleChange,
                                                                            placeholder: "1",
                                                                            className: "w-full px-3 py-2 bg-slate-800/50 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:ring-2 focus:ring-violet-500 focus:border-transparent transition-all"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                            lineNumber: 1336,
                                                                            columnNumber: 25
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1334,
                                                                    columnNumber: 23
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                            lineNumber: 1309,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                    className: "block text-sm font-medium text-slate-300 mb-2",
                                                                    children: "Product Tags"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1348,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                    type: "text",
                                                                    name: "productTags",
                                                                    value: formData.productTags,
                                                                    onChange: handleChange,
                                                                    placeholder: "tag1, tag2, tag3",
                                                                    className: "w-full px-3 py-2 bg-slate-800/50 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:ring-2 focus:ring-violet-500 focus:border-transparent transition-all"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1349,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                    className: "text-xs text-slate-400 mt-1",
                                                                    children: "Comma-separated tags"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1357,
                                                                    columnNumber: 23
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                            lineNumber: 1347,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                    lineNumber: 1164,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                            lineNumber: 1161,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "space-y-4",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                    className: "text-lg font-semibold text-white border-b border-slate-800 pb-2",
                                                    children: "Publishing"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                    lineNumber: 1364,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "space-y-3",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                            className: "flex items-center gap-2",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                    type: "checkbox",
                                                                    name: "published",
                                                                    checked: formData.published,
                                                                    onChange: handleChange,
                                                                    className: "rounded bg-slate-800/50 border-slate-700 text-violet-500 focus:ring-violet-500 focus:ring-offset-slate-900"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1368,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: "text-sm text-slate-300",
                                                                    children: "Published"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1375,
                                                                    columnNumber: 23
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                            lineNumber: 1367,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                            className: "flex items-center gap-2",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                    type: "checkbox",
                                                                    name: "visibleIndividually",
                                                                    checked: formData.visibleIndividually,
                                                                    onChange: handleChange,
                                                                    className: "rounded bg-slate-800/50 border-slate-700 text-violet-500 focus:ring-violet-500 focus:ring-offset-slate-900"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1379,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: "text-sm text-slate-300",
                                                                    children: "Visible individually"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1386,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: "text-xs text-slate-400",
                                                                    children: "(can be accessed from catalog)"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1387,
                                                                    columnNumber: 23
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                            lineNumber: 1378,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                            className: "flex items-center gap-2",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                    type: "checkbox",
                                                                    name: "allowCustomerReviews",
                                                                    checked: formData.allowCustomerReviews,
                                                                    onChange: handleChange,
                                                                    className: "rounded bg-slate-800/50 border-slate-700 text-violet-500 focus:ring-violet-500 focus:ring-offset-slate-900"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1391,
                                                                    columnNumber: 3
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: "text-sm text-slate-300",
                                                                    children: "Allow customer reviews"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1398,
                                                                    columnNumber: 3
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                            lineNumber: 1390,
                                                            columnNumber: 1
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                            className: "flex items-center gap-2",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                    type: "checkbox",
                                                                    name: "showOnHomepage",
                                                                    checked: formData.showOnHomepage,
                                                                    onChange: handleChange,
                                                                    className: "rounded bg-slate-800/50 border-slate-700 text-violet-500 focus:ring-violet-500 focus:ring-offset-slate-900"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1402,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: "text-sm text-slate-300",
                                                                    children: "Show on home page"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1409,
                                                                    columnNumber: 23
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                            lineNumber: 1401,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                    lineNumber: 1366,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "grid md:grid-cols-2 gap-4",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                    className: "block text-sm font-medium text-slate-300 mb-2",
                                                                    children: "Available Start Date/Time"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1415,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                    type: "datetime-local",
                                                                    name: "availableStartDate",
                                                                    value: formData.availableStartDate,
                                                                    onChange: handleChange,
                                                                    className: "w-full px-3 py-2 bg-slate-800/50 border border-slate-700 rounded-xl text-white focus:ring-2 focus:ring-violet-500 focus:border-transparent transition-all"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1416,
                                                                    columnNumber: 23
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                            lineNumber: 1414,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                    className: "block text-sm font-medium text-slate-300 mb-2",
                                                                    children: "Available End Date/Time"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1426,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                    type: "datetime-local",
                                                                    name: "availableEndDate",
                                                                    value: formData.availableEndDate,
                                                                    onChange: handleChange,
                                                                    className: "w-full px-3 py-2 bg-slate-800/50 border border-slate-700 rounded-xl text-white focus:ring-2 focus:ring-violet-500 focus:border-transparent transition-all"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1427,
                                                                    columnNumber: 23
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                            lineNumber: 1425,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                    lineNumber: 1413,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                            lineNumber: 1363,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "space-y-4",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                    className: "text-lg font-semibold text-white border-b border-slate-800 pb-2",
                                                    children: "Admin Comment"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                    lineNumber: 1440,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                                                        name: "adminComment",
                                                        value: formData.adminComment,
                                                        onChange: handleChange,
                                                        placeholder: "Internal notes (not visible to customers)",
                                                        rows: 3,
                                                        className: "w-full px-3 py-2 bg-slate-800/50 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:ring-2 focus:ring-violet-500 focus:border-transparent transition-all"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                        lineNumber: 1442,
                                                        columnNumber: 21
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                    lineNumber: 1441,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                            lineNumber: 1439,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                    lineNumber: 1159,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TabsContent"], {
                                    value: "prices",
                                    className: "space-y-2 mt-2",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "space-y-4",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                    className: "text-lg font-semibold text-white border-b border-slate-800 pb-2",
                                                    children: "Price"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                    lineNumber: 1458,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "grid md:grid-cols-3 gap-4",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                    className: "block text-sm font-medium text-slate-300 mb-2",
                                                                    children: [
                                                                        "Price ($) ",
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                            className: "text-red-500",
                                                                            children: "*"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                            lineNumber: 1463,
                                                                            columnNumber: 35
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1462,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                    type: "number",
                                                                    name: "price",
                                                                    value: formData.price,
                                                                    onChange: handleChange,
                                                                    placeholder: "0.00",
                                                                    step: "0.01",
                                                                    className: "w-full px-3 py-2 bg-slate-800/50 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:ring-2 focus:ring-violet-500 focus:border-transparent transition-all",
                                                                    required: true
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1465,
                                                                    columnNumber: 23
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                            lineNumber: 1461,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                    className: "block text-sm font-medium text-slate-300 mb-2",
                                                                    children: "Old Price ($)"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1478,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                    type: "number",
                                                                    name: "oldPrice",
                                                                    value: formData.oldPrice,
                                                                    onChange: handleChange,
                                                                    placeholder: "0.00",
                                                                    step: "0.01",
                                                                    className: "w-full px-3 py-2 bg-slate-800/50 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:ring-2 focus:ring-violet-500 focus:border-transparent transition-all"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1479,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                    className: "text-xs text-slate-400 mt-1",
                                                                    children: "Shows as strikethrough"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1488,
                                                                    columnNumber: 23
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                            lineNumber: 1477,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                    className: "block text-sm font-medium text-slate-300 mb-2",
                                                                    children: "Product Cost ($)"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1492,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                    type: "number",
                                                                    name: "cost",
                                                                    value: formData.cost,
                                                                    onChange: handleChange,
                                                                    placeholder: "0.00",
                                                                    step: "0.01",
                                                                    className: "w-full px-3 py-2 bg-slate-800/50 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:ring-2 focus:ring-violet-500 focus:border-transparent transition-all"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1493,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                    className: "text-xs text-slate-400 mt-1",
                                                                    children: "For profit calculation"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1502,
                                                                    columnNumber: 23
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                            lineNumber: 1491,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                    lineNumber: 1460,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "space-y-3",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                            className: "flex items-center gap-2",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                    type: "checkbox",
                                                                    name: "disableBuyButton",
                                                                    checked: formData.disableBuyButton,
                                                                    onChange: handleChange,
                                                                    className: "rounded bg-slate-800/50 border-slate-700 text-violet-500 focus:ring-violet-500 focus:ring-offset-slate-900"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1508,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: "text-sm text-slate-300",
                                                                    children: "Disable buy button"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1515,
                                                                    columnNumber: 23
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                            lineNumber: 1507,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                            className: "flex items-center gap-2",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                    type: "checkbox",
                                                                    name: "disableWishlistButton",
                                                                    checked: formData.disableWishlistButton,
                                                                    onChange: handleChange,
                                                                    className: "rounded bg-slate-800/50 border-slate-700 text-violet-500 focus:ring-violet-500 focus:ring-offset-slate-900"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1519,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: "text-sm text-slate-300",
                                                                    children: "Disable wishlist button"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1526,
                                                                    columnNumber: 23
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                            lineNumber: 1518,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                            className: "flex items-center gap-2",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                    type: "checkbox",
                                                                    name: "callForPrice",
                                                                    checked: formData.callForPrice,
                                                                    onChange: handleChange,
                                                                    className: "rounded bg-slate-800/50 border-slate-700 text-violet-500 focus:ring-violet-500 focus:ring-offset-slate-900"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1530,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: "text-sm text-slate-300",
                                                                    children: "Call for price"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1537,
                                                                    columnNumber: 23
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                            lineNumber: 1529,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                            className: "flex items-center gap-2",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                    type: "checkbox",
                                                                    name: "customerEntersPrice",
                                                                    checked: formData.customerEntersPrice,
                                                                    onChange: handleChange,
                                                                    className: "rounded bg-slate-800/50 border-slate-700 text-violet-500 focus:ring-violet-500 focus:ring-offset-slate-900"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1541,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: "text-sm text-slate-300",
                                                                    children: "Customer enters price"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1548,
                                                                    columnNumber: 23
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                            lineNumber: 1540,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                    lineNumber: 1506,
                                                    columnNumber: 19
                                                }, this),
                                                formData.customerEntersPrice && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "grid md:grid-cols-2 gap-4 bg-slate-800/30 border border-slate-700 p-4 rounded-xl",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                    className: "block text-sm font-medium text-slate-300 mb-2",
                                                                    children: "Minimum Amount"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1555,
                                                                    columnNumber: 25
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                    type: "number",
                                                                    name: "minimumCustomerEnteredPrice",
                                                                    value: formData.minimumCustomerEnteredPrice,
                                                                    onChange: handleChange,
                                                                    placeholder: "0.00",
                                                                    step: "0.01",
                                                                    className: "w-full px-3 py-2 bg-slate-800/50 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:ring-2 focus:ring-violet-500 focus:border-transparent transition-all"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1556,
                                                                    columnNumber: 25
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                            lineNumber: 1554,
                                                            columnNumber: 23
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                    className: "block text-sm font-medium text-slate-300 mb-2",
                                                                    children: "Maximum Amount"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1568,
                                                                    columnNumber: 25
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                    type: "number",
                                                                    name: "maximumCustomerEnteredPrice",
                                                                    value: formData.maximumCustomerEnteredPrice,
                                                                    onChange: handleChange,
                                                                    placeholder: "0.00",
                                                                    step: "0.01",
                                                                    className: "w-full px-3 py-2 bg-slate-800/50 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:ring-2 focus:ring-violet-500 focus:border-transparent transition-all"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1569,
                                                                    columnNumber: 25
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                            lineNumber: 1567,
                                                            columnNumber: 23
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                    lineNumber: 1553,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                            lineNumber: 1457,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "space-y-4",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                    className: "text-lg font-semibold text-white border-b border-slate-800 pb-2",
                                                    children: "Pre-order"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                    lineNumber: 1585,
                                                    columnNumber: 3
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                    className: "flex items-center gap-2",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                            type: "checkbox",
                                                            name: "availableStartDate",
                                                            checked: !!formData.availableStartDate,
                                                            onChange: handleChange,
                                                            className: "rounded bg-slate-800/50 border-slate-700 text-violet-500 focus:ring-violet-500 focus:ring-offset-slate-900"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                            lineNumber: 1588,
                                                            columnNumber: 5
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "text-sm text-slate-300",
                                                            children: "Available for pre-order"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                            lineNumber: 1595,
                                                            columnNumber: 5
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                    lineNumber: 1587,
                                                    columnNumber: 3
                                                }, this),
                                                formData.availableStartDate && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "grid md:grid-cols-2 gap-4 bg-slate-800/30 border border-slate-700 p-4 rounded-xl",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                    className: "block text-sm font-medium text-slate-300 mb-2",
                                                                    children: "Start Date"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1601,
                                                                    columnNumber: 9
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                    type: "datetime-local",
                                                                    name: "availableStartDate",
                                                                    value: formData.availableStartDate || '',
                                                                    onChange: handleChange,
                                                                    className: "w-full px-3 py-2 bg-slate-800/50 border border-slate-700 rounded-xl text-white focus:ring-2 focus:ring-violet-500 focus:border-transparent transition-all"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1602,
                                                                    columnNumber: 9
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                            lineNumber: 1600,
                                                            columnNumber: 7
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                    className: "block text-sm font-medium text-slate-300 mb-2",
                                                                    children: "End Date"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1612,
                                                                    columnNumber: 9
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                    type: "datetime-local",
                                                                    name: "availableEndDate",
                                                                    value: formData.availableEndDate || '',
                                                                    onChange: handleChange,
                                                                    className: "w-full px-3 py-2 bg-slate-800/50 border border-slate-700 rounded-xl text-white focus:ring-2 focus:ring-violet-500 focus:border-transparent transition-all"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1613,
                                                                    columnNumber: 9
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                            lineNumber: 1611,
                                                            columnNumber: 7
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                    lineNumber: 1599,
                                                    columnNumber: 5
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                            lineNumber: 1584,
                                            columnNumber: 1
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "space-y-4",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                    className: "text-lg font-semibold text-white border-b border-slate-800 pb-2",
                                                    children: "Mark as New"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                    lineNumber: 1627,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                    className: "flex items-center gap-2",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                            type: "checkbox",
                                                            name: "markAsNew",
                                                            checked: formData.markAsNew,
                                                            onChange: handleChange,
                                                            className: "rounded bg-slate-800/50 border-slate-700 text-violet-500 focus:ring-violet-500 focus:ring-offset-slate-900"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                            lineNumber: 1630,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "text-sm text-slate-300",
                                                            children: "Mark as new product"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                            lineNumber: 1637,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                    lineNumber: 1629,
                                                    columnNumber: 19
                                                }, this),
                                                formData.markAsNew && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "grid md:grid-cols-2 gap-4 bg-slate-800/30 border border-slate-700 p-4 rounded-xl",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                    className: "block text-sm font-medium text-slate-300 mb-2",
                                                                    children: "Start Date"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1643,
                                                                    columnNumber: 25
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                    type: "datetime-local",
                                                                    name: "markAsNewStartDate",
                                                                    value: formData.markAsNewStartDate,
                                                                    onChange: handleChange,
                                                                    className: "w-full px-3 py-2 bg-slate-800/50 border border-slate-700 rounded-xl text-white focus:ring-2 focus:ring-violet-500 focus:border-transparent transition-all"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1644,
                                                                    columnNumber: 25
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                            lineNumber: 1642,
                                                            columnNumber: 23
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                    className: "block text-sm font-medium text-slate-300 mb-2",
                                                                    children: "End Date"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1654,
                                                                    columnNumber: 25
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                    type: "datetime-local",
                                                                    name: "markAsNewEndDate",
                                                                    value: formData.markAsNewEndDate,
                                                                    onChange: handleChange,
                                                                    className: "w-full px-3 py-2 bg-slate-800/50 border border-slate-700 rounded-xl text-white focus:ring-2 focus:ring-violet-500 focus:border-transparent transition-all"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1655,
                                                                    columnNumber: 25
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                            lineNumber: 1653,
                                                            columnNumber: 23
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                    lineNumber: 1641,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                            lineNumber: 1626,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "space-y-4",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                    className: "text-lg font-semibold text-white border-b border-slate-800 pb-2",
                                                    children: "Tax"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                    lineNumber: 1669,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                    className: "flex items-center gap-2",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                            type: "checkbox",
                                                            name: "taxExempt",
                                                            checked: formData.taxExempt,
                                                            onChange: handleChange,
                                                            className: "rounded bg-slate-800/50 border-slate-700 text-violet-500 focus:ring-violet-500 focus:ring-offset-slate-900"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                            lineNumber: 1672,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "text-sm text-slate-300",
                                                            children: "Tax exempt"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                            lineNumber: 1679,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                    lineNumber: 1671,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                            className: "block text-sm font-medium text-slate-300 mb-2",
                                                            children: "Tax Category"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                            lineNumber: 1683,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                                            name: "taxCategoryId",
                                                            value: formData.taxCategoryId,
                                                            onChange: handleChange,
                                                            className: "w-full px-3 py-2 bg-slate-800/50 border border-slate-700 rounded-xl text-white focus:ring-2 focus:ring-violet-500 focus:border-transparent transition-all",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                    value: "",
                                                                    children: "None"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1690,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                    value: "1",
                                                                    children: "Standard"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1691,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                    value: "2",
                                                                    children: "Books"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1692,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                    value: "3",
                                                                    children: "Electronics"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1693,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                    value: "4",
                                                                    children: "Food & Beverages"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1694,
                                                                    columnNumber: 23
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                            lineNumber: 1684,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                    lineNumber: 1682,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                            lineNumber: 1668,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                    lineNumber: 1455,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TabsContent"], {
                                    value: "inventory",
                                    className: "space-y-2 mt-2",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "space-y-4",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                    className: "text-lg font-semibold text-white border-b border-slate-800 pb-2",
                                                    children: "Inventory Method"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                    lineNumber: 1704,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                            className: "block text-sm font-medium text-slate-300 mb-2",
                                                            children: "Inventory Method"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                            lineNumber: 1707,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                                            name: "manageInventory",
                                                            value: formData.manageInventory,
                                                            onChange: handleChange,
                                                            className: "w-full px-3 py-2 bg-slate-800/50 border border-slate-700 rounded-xl text-white focus:ring-2 focus:ring-violet-500 focus:border-transparent transition-all",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                    value: "dont-track",
                                                                    children: "Don't track inventory"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1714,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                    value: "track",
                                                                    children: "Track inventory"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1715,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                    value: "track-by-attributes",
                                                                    children: "Track inventory by product attributes"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1716,
                                                                    columnNumber: 23
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                            lineNumber: 1708,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                            className: "text-xs text-slate-400 mt-1",
                                                            children: "Choose how you want to manage inventory for this product"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                            lineNumber: 1718,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                    lineNumber: 1706,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                            lineNumber: 1703,
                                            columnNumber: 17
                                        }, this),
                                        formData.manageInventory === 'track' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "space-y-4",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                            className: "text-lg font-semibold text-white border-b border-slate-800 pb-2",
                                                            children: "Stock Quantity"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                            lineNumber: 1728,
                                                            columnNumber: 23
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "grid md:grid-cols-2 gap-4",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                            className: "block text-sm font-medium text-slate-300 mb-2",
                                                                            children: [
                                                                                "Stock Quantity ",
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                    className: "text-red-500",
                                                                                    children: "*"
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                                    lineNumber: 1733,
                                                                                    columnNumber: 44
                                                                                }, this)
                                                                            ]
                                                                        }, void 0, true, {
                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                            lineNumber: 1732,
                                                                            columnNumber: 27
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                            type: "number",
                                                                            name: "stockQuantity",
                                                                            value: formData.stockQuantity,
                                                                            onChange: handleChange,
                                                                            placeholder: "0",
                                                                            className: "w-full px-3 py-2 bg-slate-800/50 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:ring-2 focus:ring-violet-500 focus:border-transparent transition-all",
                                                                            required: true
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                            lineNumber: 1735,
                                                                            columnNumber: 27
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1731,
                                                                    columnNumber: 25
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                            className: "block text-sm font-medium text-slate-300 mb-2",
                                                                            children: "Minimum Stock Quantity"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                            lineNumber: 1747,
                                                                            columnNumber: 27
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                            type: "number",
                                                                            name: "minStockQuantity",
                                                                            value: formData.minStockQuantity,
                                                                            onChange: handleChange,
                                                                            placeholder: "0",
                                                                            className: "w-full px-3 py-2 bg-slate-800/50 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:ring-2 focus:ring-violet-500 focus:border-transparent transition-all"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                            lineNumber: 1748,
                                                                            columnNumber: 27
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1746,
                                                                    columnNumber: 25
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                            lineNumber: 1730,
                                                            columnNumber: 23
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "grid md:grid-cols-2 gap-4",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                            className: "block text-sm font-medium text-slate-300 mb-2",
                                                                            children: "Low Stock Activity"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                            lineNumber: 1761,
                                                                            columnNumber: 27
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                                                            name: "lowStockActivity",
                                                                            value: formData.lowStockActivity,
                                                                            onChange: handleChange,
                                                                            className: "w-full px-3 py-2 bg-slate-800/50 border border-slate-700 rounded-xl text-white focus:ring-2 focus:ring-violet-500 focus:border-transparent transition-all",
                                                                            children: [
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                                    value: "nothing",
                                                                                    children: "Nothing"
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                                    lineNumber: 1768,
                                                                                    columnNumber: 29
                                                                                }, this),
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                                    value: "disable-buy",
                                                                                    children: "Disable buy button"
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                                    lineNumber: 1769,
                                                                                    columnNumber: 29
                                                                                }, this),
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                                    value: "unpublish",
                                                                                    children: "Unpublish product"
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                                    lineNumber: 1770,
                                                                                    columnNumber: 29
                                                                                }, this)
                                                                            ]
                                                                        }, void 0, true, {
                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                            lineNumber: 1762,
                                                                            columnNumber: 27
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1760,
                                                                    columnNumber: 25
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                            className: "block text-sm font-medium text-slate-300 mb-2",
                                                                            children: "Notify Admin for Quantity Below"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                            lineNumber: 1775,
                                                                            columnNumber: 27
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                            type: "number",
                                                                            name: "notifyAdminForQuantityBelow",
                                                                            value: formData.notifyAdminForQuantityBelow,
                                                                            onChange: handleChange,
                                                                            placeholder: "1",
                                                                            className: "w-full px-3 py-2 bg-slate-800/50 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:ring-2 focus:ring-violet-500 focus:border-transparent transition-all"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                            lineNumber: 1776,
                                                                            columnNumber: 27
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1774,
                                                                    columnNumber: 25
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                            lineNumber: 1759,
                                                            columnNumber: 23
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                    className: "block text-sm font-medium text-slate-300 mb-2",
                                                                    children: "Backorders"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1788,
                                                                    columnNumber: 25
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                                                    name: "backorders",
                                                                    value: formData.backorders,
                                                                    onChange: handleChange,
                                                                    className: "w-full px-3 py-2 bg-slate-800/50 border border-slate-700 rounded-xl text-white focus:ring-2 focus:ring-violet-500 focus:border-transparent transition-all",
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                            value: "no-backorders",
                                                                            children: "No backorders"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                            lineNumber: 1795,
                                                                            columnNumber: 27
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                            value: "allow-qty-below-zero",
                                                                            children: "Allow qty below 0"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                            lineNumber: 1796,
                                                                            columnNumber: 27
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                            value: "allow-qty-below-zero-and-notify",
                                                                            children: "Allow qty below 0 and notify customer"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                            lineNumber: 1797,
                                                                            columnNumber: 27
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1789,
                                                                    columnNumber: 25
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                            lineNumber: 1787,
                                                            columnNumber: 23
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "space-y-3",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                    className: "flex items-center gap-2",
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                            type: "checkbox",
                                                                            name: "displayStockAvailability",
                                                                            checked: formData.displayStockAvailability,
                                                                            onChange: handleChange,
                                                                            className: "rounded bg-slate-800/50 border-slate-700 text-violet-500 focus:ring-violet-500 focus:ring-offset-slate-900"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                            lineNumber: 1803,
                                                                            columnNumber: 27
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                            className: "text-sm text-slate-300",
                                                                            children: "Display stock availability"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                            lineNumber: 1810,
                                                                            columnNumber: 27
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1802,
                                                                    columnNumber: 25
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                    className: "flex items-center gap-2",
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                            type: "checkbox",
                                                                            name: "displayStockQuantity",
                                                                            checked: formData.displayStockQuantity,
                                                                            onChange: handleChange,
                                                                            className: "rounded bg-slate-800/50 border-slate-700 text-violet-500 focus:ring-violet-500 focus:ring-offset-slate-900"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                            lineNumber: 1814,
                                                                            columnNumber: 27
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                            className: "text-sm text-slate-300",
                                                                            children: "Display stock quantity"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                            lineNumber: 1821,
                                                                            columnNumber: 27
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1813,
                                                                    columnNumber: 25
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                    className: "flex items-center gap-2",
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                            type: "checkbox",
                                                                            name: "allowBackInStockSubscriptions",
                                                                            checked: formData.allowBackInStockSubscriptions,
                                                                            onChange: handleChange,
                                                                            className: "rounded bg-slate-800/50 border-slate-700 text-violet-500 focus:ring-violet-500 focus:ring-offset-slate-900"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                            lineNumber: 1825,
                                                                            columnNumber: 27
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                            className: "text-sm text-slate-300",
                                                                            children: "Allow back in stock subscriptions"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                            lineNumber: 1832,
                                                                            columnNumber: 27
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1824,
                                                                    columnNumber: 25
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                            lineNumber: 1801,
                                                            columnNumber: 23
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                    lineNumber: 1727,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "space-y-4",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                            className: "text-lg font-semibold text-white border-b border-slate-800 pb-2",
                                                            children: "Multiple Warehouses"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                            lineNumber: 1838,
                                                            columnNumber: 23
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                    className: "block text-sm font-medium text-slate-300 mb-2",
                                                                    children: "Product Availability Range"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1841,
                                                                    columnNumber: 25
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                                                    name: "productAvailabilityRange",
                                                                    value: formData.productAvailabilityRange,
                                                                    onChange: handleChange,
                                                                    className: "w-full px-3 py-2 bg-slate-800/50 border border-slate-700 rounded-xl text-white focus:ring-2 focus:ring-violet-500 focus:border-transparent transition-all",
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                            value: "",
                                                                            children: "None"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                            lineNumber: 1848,
                                                                            columnNumber: 27
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                            value: "1-2-days",
                                                                            children: "1-2 days"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                            lineNumber: 1849,
                                                                            columnNumber: 27
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                            value: "3-5-days",
                                                                            children: "3-5 days"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                            lineNumber: 1850,
                                                                            columnNumber: 27
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                            value: "1-week",
                                                                            children: "1 week"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                            lineNumber: 1851,
                                                                            columnNumber: 27
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                            value: "2-weeks",
                                                                            children: "2 weeks"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                            lineNumber: 1852,
                                                                            columnNumber: 27
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1842,
                                                                    columnNumber: 25
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                            lineNumber: 1840,
                                                            columnNumber: 23
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                    lineNumber: 1837,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "space-y-4",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                    className: "text-lg font-semibold text-white border-b border-slate-800 pb-2",
                                                    children: "Cart Settings"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                    lineNumber: 1861,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "grid md:grid-cols-2 gap-4",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                    className: "block text-sm font-medium text-slate-300 mb-2",
                                                                    children: "Minimum Cart Quantity"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1865,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                    type: "number",
                                                                    name: "minCartQuantity",
                                                                    value: formData.minCartQuantity,
                                                                    onChange: handleChange,
                                                                    placeholder: "1",
                                                                    className: "w-full px-3 py-2 bg-slate-800/50 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:ring-2 focus:ring-violet-500 focus:border-transparent transition-all"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1866,
                                                                    columnNumber: 23
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                            lineNumber: 1864,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                    className: "block text-sm font-medium text-slate-300 mb-2",
                                                                    children: "Maximum Cart Quantity"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1877,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                    type: "number",
                                                                    name: "maxCartQuantity",
                                                                    value: formData.maxCartQuantity,
                                                                    onChange: handleChange,
                                                                    placeholder: "10000",
                                                                    className: "w-full px-3 py-2 bg-slate-800/50 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:ring-2 focus:ring-violet-500 focus:border-transparent transition-all"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1878,
                                                                    columnNumber: 23
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                            lineNumber: 1876,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                    lineNumber: 1863,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                            className: "block text-sm font-medium text-slate-300 mb-2",
                                                            children: "Allowed Quantities"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                            lineNumber: 1890,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                            type: "text",
                                                            name: "allowedQuantities",
                                                            value: formData.allowedQuantities,
                                                            onChange: handleChange,
                                                            placeholder: "e.g., 1, 5, 10, 20",
                                                            className: "w-full px-3 py-2 bg-slate-800/50 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:ring-2 focus:ring-violet-500 focus:border-transparent transition-all"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                            lineNumber: 1891,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                            className: "text-xs text-slate-400 mt-1",
                                                            children: "Comma-separated list of quantities. Leave empty to allow any quantity."
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                            lineNumber: 1899,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                    lineNumber: 1889,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                    className: "flex items-center gap-2",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                            type: "checkbox",
                                                            name: "notReturnable",
                                                            checked: formData.notReturnable,
                                                            onChange: handleChange,
                                                            className: "rounded bg-slate-800/50 border-slate-700 text-violet-500 focus:ring-violet-500 focus:ring-offset-slate-900"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                            lineNumber: 1905,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "text-sm text-slate-300",
                                                            children: "Not returnable"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                            lineNumber: 1912,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                    lineNumber: 1904,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                            lineNumber: 1860,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                    lineNumber: 1701,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TabsContent"], {
                                    value: "shipping",
                                    className: "space-y-2 mt-2",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "space-y-4",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                    className: "text-lg font-semibold text-white border-b border-slate-800 pb-2",
                                                    children: "Shipping Settings"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                    lineNumber: 1921,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                    className: "flex items-center gap-2",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                            type: "checkbox",
                                                            name: "isShipEnabled",
                                                            checked: formData.isShipEnabled,
                                                            onChange: handleChange,
                                                            className: "rounded bg-slate-800/50 border-slate-700 text-violet-500 focus:ring-violet-500 focus:ring-offset-slate-900"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                            lineNumber: 1924,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "text-sm text-slate-300",
                                                            children: "Shipping enabled"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                            lineNumber: 1931,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                    lineNumber: 1923,
                                                    columnNumber: 19
                                                }, this),
                                                formData.isShipEnabled && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "space-y-4 bg-slate-800/30 border border-slate-700 p-4 rounded-xl",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "space-y-3",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                    className: "flex items-center gap-2",
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                            type: "checkbox",
                                                                            name: "isFreeShipping",
                                                                            checked: formData.isFreeShipping,
                                                                            onChange: handleChange,
                                                                            className: "rounded bg-slate-800/50 border-slate-700 text-violet-500 focus:ring-violet-500 focus:ring-offset-slate-900"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                            lineNumber: 1938,
                                                                            columnNumber: 27
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                            className: "text-sm text-slate-300",
                                                                            children: "Free shipping"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                            lineNumber: 1945,
                                                                            columnNumber: 27
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1937,
                                                                    columnNumber: 25
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                    className: "flex items-center gap-2",
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                            type: "checkbox",
                                                                            name: "shipSeparately",
                                                                            checked: formData.shipSeparately,
                                                                            onChange: handleChange,
                                                                            className: "rounded bg-slate-800/50 border-slate-700 text-violet-500 focus:ring-violet-500 focus:ring-offset-slate-900"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                            lineNumber: 1949,
                                                                            columnNumber: 27
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                            className: "text-sm text-slate-300",
                                                                            children: "Ship separately (not with other products)"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                            lineNumber: 1956,
                                                                            columnNumber: 27
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1948,
                                                                    columnNumber: 25
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                            lineNumber: 1936,
                                                            columnNumber: 23
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                    className: "block text-sm font-medium text-slate-300 mb-2",
                                                                    children: "Additional Shipping Charge ($)"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1961,
                                                                    columnNumber: 25
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                    type: "number",
                                                                    name: "additionalShippingCharge",
                                                                    value: formData.additionalShippingCharge,
                                                                    onChange: handleChange,
                                                                    placeholder: "0.00",
                                                                    step: "0.01",
                                                                    className: "w-full px-3 py-2 bg-slate-800/50 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:ring-2 focus:ring-violet-500 focus:border-transparent transition-all"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1962,
                                                                    columnNumber: 25
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                            lineNumber: 1960,
                                                            columnNumber: 23
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                    className: "block text-sm font-medium text-slate-300 mb-2",
                                                                    children: "Delivery Date"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1974,
                                                                    columnNumber: 25
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                                                    name: "deliveryDateId",
                                                                    value: formData.deliveryDateId,
                                                                    onChange: handleChange,
                                                                    className: "w-full px-3 py-2 bg-slate-800/50 border border-slate-700 rounded-xl text-white focus:ring-2 focus:ring-violet-500 focus:border-transparent transition-all",
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                            value: "",
                                                                            children: "None"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                            lineNumber: 1981,
                                                                            columnNumber: 27
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                            value: "1",
                                                                            children: "1-2 days"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                            lineNumber: 1982,
                                                                            columnNumber: 27
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                            value: "2",
                                                                            children: "3-5 days"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                            lineNumber: 1983,
                                                                            columnNumber: 27
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                            value: "3",
                                                                            children: "1 week"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                            lineNumber: 1984,
                                                                            columnNumber: 27
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                            value: "4",
                                                                            children: "2 weeks"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                            lineNumber: 1985,
                                                                            columnNumber: 27
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1975,
                                                                    columnNumber: 25
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                            lineNumber: 1973,
                                                            columnNumber: 23
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                    lineNumber: 1935,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                            lineNumber: 1920,
                                            columnNumber: 17
                                        }, this),
                                        formData.isShipEnabled && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "space-y-4",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                    className: "text-lg font-semibold text-white border-b border-slate-800 pb-2",
                                                    children: "Dimensions"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                    lineNumber: 1995,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "grid md:grid-cols-4 gap-4",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                    className: "block text-sm font-medium text-slate-300 mb-2",
                                                                    children: "Weight (kg)"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 1999,
                                                                    columnNumber: 25
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                    type: "number",
                                                                    name: "weight",
                                                                    value: formData.weight,
                                                                    onChange: handleChange,
                                                                    placeholder: "0.00",
                                                                    step: "0.01",
                                                                    className: "w-full px-3 py-2 bg-slate-800/50 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:ring-2 focus:ring-violet-500 focus:border-transparent transition-all"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 2000,
                                                                    columnNumber: 25
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                            lineNumber: 1998,
                                                            columnNumber: 23
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                    className: "block text-sm font-medium text-slate-300 mb-2",
                                                                    children: "Length (cm)"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 2012,
                                                                    columnNumber: 25
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                    type: "number",
                                                                    name: "length",
                                                                    value: formData.length,
                                                                    onChange: handleChange,
                                                                    placeholder: "0.00",
                                                                    step: "0.01",
                                                                    className: "w-full px-3 py-2 bg-slate-800/50 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:ring-2 focus:ring-violet-500 focus:border-transparent transition-all"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 2013,
                                                                    columnNumber: 25
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                            lineNumber: 2011,
                                                            columnNumber: 23
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                    className: "block text-sm font-medium text-slate-300 mb-2",
                                                                    children: "Width (cm)"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 2025,
                                                                    columnNumber: 25
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                    type: "number",
                                                                    name: "width",
                                                                    value: formData.width,
                                                                    onChange: handleChange,
                                                                    placeholder: "0.00",
                                                                    step: "0.01",
                                                                    className: "w-full px-3 py-2 bg-slate-800/50 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:ring-2 focus:ring-violet-500 focus:border-transparent transition-all"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 2026,
                                                                    columnNumber: 25
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                            lineNumber: 2024,
                                                            columnNumber: 23
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                    className: "block text-sm font-medium text-slate-300 mb-2",
                                                                    children: "Height (cm)"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 2038,
                                                                    columnNumber: 25
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                    type: "number",
                                                                    name: "height",
                                                                    value: formData.height,
                                                                    onChange: handleChange,
                                                                    placeholder: "0.00",
                                                                    step: "0.01",
                                                                    className: "w-full px-3 py-2 bg-slate-800/50 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:ring-2 focus:ring-violet-500 focus:border-transparent transition-all"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 2039,
                                                                    columnNumber: 25
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                            lineNumber: 2037,
                                                            columnNumber: 23
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                    lineNumber: 1997,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                            lineNumber: 1994,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                    lineNumber: 1918,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TabsContent"], {
                                    value: "related-products",
                                    className: "space-y-2 mt-2",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "space-y-4",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                    className: "text-lg font-semibold text-white border-b border-slate-800 pb-2",
                                                    children: "Related Products"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                    lineNumber: 2058,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-sm text-slate-400",
                                                    children: "These products will be shown on the product details page as recommended items"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                    lineNumber: 2059,
                                                    columnNumber: 19
                                                }, this),
                                                formData.relatedProducts.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "space-y-2",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                            className: "block text-sm font-medium text-slate-300",
                                                            children: "Selected Products"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                            lineNumber: 2066,
                                                            columnNumber: 23
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "border border-slate-700 rounded-xl p-4 space-y-2 bg-slate-800/30",
                                                            children: formData.relatedProducts.map((productId)=>{
                                                                const product = availableProducts.find((p)=>p.id === productId);
                                                                return product ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: "flex items-center justify-between p-3 bg-slate-800/50 border border-slate-700 rounded-lg",
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                            className: "flex items-center gap-3",
                                                                            children: [
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                    className: "w-10 h-10 bg-slate-700/50 rounded flex items-center justify-center",
                                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$package$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Package$3e$__["Package"], {
                                                                                        className: "h-5 w-5 text-slate-400"
                                                                                    }, void 0, false, {
                                                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                                        lineNumber: 2077,
                                                                                        columnNumber: 35
                                                                                    }, this)
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                                    lineNumber: 2076,
                                                                                    columnNumber: 33
                                                                                }, this),
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                    children: [
                                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                                            className: "font-medium text-sm text-white",
                                                                                            children: product.name
                                                                                        }, void 0, false, {
                                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                                            lineNumber: 2080,
                                                                                            columnNumber: 35
                                                                                        }, this),
                                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                                            className: "text-xs text-slate-400",
                                                                                            children: [
                                                                                                "SKU: ",
                                                                                                product.sku,
                                                                                                " • ",
                                                                                                product.price
                                                                                            ]
                                                                                        }, void 0, true, {
                                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                                            lineNumber: 2081,
                                                                                            columnNumber: 35
                                                                                        }, this)
                                                                                    ]
                                                                                }, void 0, true, {
                                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                                    lineNumber: 2079,
                                                                                    columnNumber: 33
                                                                                }, this)
                                                                            ]
                                                                        }, void 0, true, {
                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                            lineNumber: 2075,
                                                                            columnNumber: 31
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                            onClick: ()=>removeRelatedProduct(productId),
                                                                            className: "p-2 text-slate-400 hover:text-red-400 hover:bg-slate-700/50 rounded-lg transition-all",
                                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                                                                                className: "h-4 w-4"
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                                lineNumber: 2090,
                                                                                columnNumber: 33
                                                                            }, this)
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                            lineNumber: 2086,
                                                                            columnNumber: 31
                                                                        }, this)
                                                                    ]
                                                                }, productId, true, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 2071,
                                                                    columnNumber: 29
                                                                }, this) : null;
                                                            })
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                            lineNumber: 2067,
                                                            columnNumber: 23
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                    lineNumber: 2065,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                            className: "block text-sm font-medium text-slate-300 mb-2",
                                                            children: "Add Related Products"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                            lineNumber: 2101,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "relative",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$search$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Search$3e$__["Search"], {
                                                                    className: "absolute left-3 top-3 h-4 w-4 text-slate-400"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 2103,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                    type: "text",
                                                                    value: searchTerm,
                                                                    onChange: (e)=>setSearchTerm(e.target.value),
                                                                    placeholder: "Search products by name or SKU...",
                                                                    className: "w-full pl-10 pr-4 py-2 bg-slate-800/50 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:ring-2 focus:ring-violet-500 focus:border-transparent transition-all"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 2104,
                                                                    columnNumber: 23
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                            lineNumber: 2102,
                                                            columnNumber: 21
                                                        }, this),
                                                        searchTerm && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "mt-2 border border-slate-700 rounded-xl max-h-64 overflow-y-auto bg-slate-800/30",
                                                            children: filteredProducts.length > 0 ? filteredProducts.map((product)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: "flex items-center justify-between p-3 hover:bg-slate-800/50 cursor-pointer border-b border-slate-700 last:border-0 transition-all",
                                                                    onClick: ()=>addRelatedProduct(product.id),
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                            className: "flex items-center gap-3",
                                                                            children: [
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                    className: "w-10 h-10 bg-slate-700/50 rounded flex items-center justify-center",
                                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$package$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Package$3e$__["Package"], {
                                                                                        className: "h-5 w-5 text-slate-400"
                                                                                    }, void 0, false, {
                                                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                                        lineNumber: 2125,
                                                                                        columnNumber: 35
                                                                                    }, this)
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                                    lineNumber: 2124,
                                                                                    columnNumber: 33
                                                                                }, this),
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                    children: [
                                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                                            className: "font-medium text-sm text-white",
                                                                                            children: product.name
                                                                                        }, void 0, false, {
                                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                                            lineNumber: 2128,
                                                                                            columnNumber: 35
                                                                                        }, this),
                                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                                            className: "text-xs text-slate-400",
                                                                                            children: [
                                                                                                "SKU: ",
                                                                                                product.sku,
                                                                                                " • ",
                                                                                                product.price
                                                                                            ]
                                                                                        }, void 0, true, {
                                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                                            lineNumber: 2129,
                                                                                            columnNumber: 35
                                                                                        }, this)
                                                                                    ]
                                                                                }, void 0, true, {
                                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                                    lineNumber: 2127,
                                                                                    columnNumber: 33
                                                                                }, this)
                                                                            ]
                                                                        }, void 0, true, {
                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                            lineNumber: 2123,
                                                                            columnNumber: 31
                                                                        }, this),
                                                                        formData.relatedProducts.includes(product.id) ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                            className: "px-2 py-1 bg-violet-500/20 text-violet-400 text-xs rounded-lg border border-violet-500/30",
                                                                            children: "Added"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                            lineNumber: 2135,
                                                                            columnNumber: 33
                                                                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                            className: "px-3 py-1 bg-slate-800/50 border border-slate-700 text-slate-300 hover:bg-slate-700 rounded-lg text-xs transition-all",
                                                                            children: "Add"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                            lineNumber: 2137,
                                                                            columnNumber: 33
                                                                        }, this)
                                                                    ]
                                                                }, product.id, true, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 2118,
                                                                    columnNumber: 29
                                                                }, this)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "p-4 text-center text-sm text-slate-400",
                                                                children: "No products found"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                lineNumber: 2144,
                                                                columnNumber: 27
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                            lineNumber: 2115,
                                                            columnNumber: 23
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                    lineNumber: 2100,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                            lineNumber: 2057,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "space-y-4",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                    className: "text-lg font-semibold text-white border-b border-slate-800 pb-2",
                                                    children: "Cross-sell Products"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                    lineNumber: 2155,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-sm text-slate-400",
                                                    children: "These products will be shown in the shopping cart as additional items"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                    lineNumber: 2156,
                                                    columnNumber: 19
                                                }, this),
                                                formData.crossSellProducts.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "space-y-2",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                            className: "block text-sm font-medium text-slate-300",
                                                            children: "Selected Products"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                            lineNumber: 2163,
                                                            columnNumber: 23
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "border border-slate-700 rounded-xl p-4 space-y-2 bg-slate-800/30",
                                                            children: formData.crossSellProducts.map((productId)=>{
                                                                const product = availableProducts.find((p)=>p.id === productId);
                                                                return product ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: "flex items-center justify-between p-3 bg-cyan-500/10 border border-cyan-500/30 rounded-lg",
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                            className: "flex items-center gap-3",
                                                                            children: [
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                    className: "w-10 h-10 bg-cyan-500/20 rounded flex items-center justify-center",
                                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$shopping$2d$cart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ShoppingCart$3e$__["ShoppingCart"], {
                                                                                        className: "h-5 w-5 text-cyan-400"
                                                                                    }, void 0, false, {
                                                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                                        lineNumber: 2174,
                                                                                        columnNumber: 35
                                                                                    }, this)
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                                    lineNumber: 2173,
                                                                                    columnNumber: 33
                                                                                }, this),
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                    children: [
                                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                                            className: "font-medium text-sm text-white",
                                                                                            children: product.name
                                                                                        }, void 0, false, {
                                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                                            lineNumber: 2177,
                                                                                            columnNumber: 35
                                                                                        }, this),
                                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                                            className: "text-xs text-slate-400",
                                                                                            children: [
                                                                                                "SKU: ",
                                                                                                product.sku,
                                                                                                " • ",
                                                                                                product.price
                                                                                            ]
                                                                                        }, void 0, true, {
                                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                                            lineNumber: 2178,
                                                                                            columnNumber: 35
                                                                                        }, this)
                                                                                    ]
                                                                                }, void 0, true, {
                                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                                    lineNumber: 2176,
                                                                                    columnNumber: 33
                                                                                }, this)
                                                                            ]
                                                                        }, void 0, true, {
                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                            lineNumber: 2172,
                                                                            columnNumber: 31
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                            onClick: ()=>removeCrossSellProduct(productId),
                                                                            className: "p-2 text-slate-400 hover:text-red-400 hover:bg-slate-700/50 rounded-lg transition-all",
                                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                                                                                className: "h-4 w-4"
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                                lineNumber: 2187,
                                                                                columnNumber: 33
                                                                            }, this)
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                            lineNumber: 2183,
                                                                            columnNumber: 31
                                                                        }, this)
                                                                    ]
                                                                }, productId, true, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 2168,
                                                                    columnNumber: 29
                                                                }, this) : null;
                                                            })
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                            lineNumber: 2164,
                                                            columnNumber: 23
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                    lineNumber: 2162,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                            className: "block text-sm font-medium text-slate-300 mb-2",
                                                            children: "Add Cross-sell Products"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                            lineNumber: 2198,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "relative",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$search$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Search$3e$__["Search"], {
                                                                    className: "absolute left-3 top-3 h-4 w-4 text-slate-400"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 2200,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                    type: "text",
                                                                    value: searchTermCross,
                                                                    onChange: (e)=>setSearchTermCross(e.target.value),
                                                                    placeholder: "Search products by name or SKU...",
                                                                    className: "w-full pl-10 pr-4 py-2 bg-slate-800/50 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:ring-2 focus:ring-violet-500 focus:border-transparent transition-all"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 2201,
                                                                    columnNumber: 23
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                            lineNumber: 2199,
                                                            columnNumber: 21
                                                        }, this),
                                                        searchTermCross && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "mt-2 border border-slate-700 rounded-xl max-h-64 overflow-y-auto bg-slate-800/30",
                                                            children: filteredProductsCross.length > 0 ? filteredProductsCross.map((product)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: "flex items-center justify-between p-3 hover:bg-slate-800/50 cursor-pointer border-b border-slate-700 last:border-0 transition-all",
                                                                    onClick: ()=>addCrossSellProduct(product.id),
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                            className: "flex items-center gap-3",
                                                                            children: [
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                    className: "w-10 h-10 bg-slate-700/50 rounded flex items-center justify-center",
                                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$shopping$2d$cart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ShoppingCart$3e$__["ShoppingCart"], {
                                                                                        className: "h-5 w-5 text-slate-400"
                                                                                    }, void 0, false, {
                                                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                                        lineNumber: 2222,
                                                                                        columnNumber: 35
                                                                                    }, this)
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                                    lineNumber: 2221,
                                                                                    columnNumber: 33
                                                                                }, this),
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                    children: [
                                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                                            className: "font-medium text-sm text-white",
                                                                                            children: product.name
                                                                                        }, void 0, false, {
                                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                                            lineNumber: 2225,
                                                                                            columnNumber: 35
                                                                                        }, this),
                                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                                            className: "text-xs text-slate-400",
                                                                                            children: [
                                                                                                "SKU: ",
                                                                                                product.sku,
                                                                                                " • ",
                                                                                                product.price
                                                                                            ]
                                                                                        }, void 0, true, {
                                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                                            lineNumber: 2226,
                                                                                            columnNumber: 35
                                                                                        }, this)
                                                                                    ]
                                                                                }, void 0, true, {
                                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                                    lineNumber: 2224,
                                                                                    columnNumber: 33
                                                                                }, this)
                                                                            ]
                                                                        }, void 0, true, {
                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                            lineNumber: 2220,
                                                                            columnNumber: 31
                                                                        }, this),
                                                                        formData.crossSellProducts.includes(product.id) ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                            className: "px-2 py-1 bg-violet-500/20 text-violet-400 text-xs rounded-lg border border-violet-500/30",
                                                                            children: "Added"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                            lineNumber: 2232,
                                                                            columnNumber: 33
                                                                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                            className: "px-3 py-1 bg-slate-800/50 border border-slate-700 text-slate-300 hover:bg-slate-700 rounded-lg text-xs transition-all",
                                                                            children: "Add"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                            lineNumber: 2234,
                                                                            columnNumber: 33
                                                                        }, this)
                                                                    ]
                                                                }, product.id, true, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 2215,
                                                                    columnNumber: 29
                                                                }, this)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "p-4 text-center text-sm text-slate-400",
                                                                children: "No products found"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                lineNumber: 2241,
                                                                columnNumber: 27
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                            lineNumber: 2212,
                                                            columnNumber: 23
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                    lineNumber: 2197,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                            lineNumber: 2154,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "bg-violet-500/10 border border-violet-500/30 rounded-xl p-4",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                                    className: "font-semibold text-sm text-violet-400 mb-2",
                                                    children: "Tips"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                    lineNumber: 2252,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                                    className: "text-sm text-slate-300 space-y-1",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                            children: [
                                                                "• ",
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                                                    className: "text-white",
                                                                    children: "Related Products:"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 2254,
                                                                    columnNumber: 27
                                                                }, this),
                                                                " Shown on product detail page to encourage additional purchases"
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                            lineNumber: 2254,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                            children: [
                                                                "• ",
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                                                    className: "text-white",
                                                                    children: "Cross-sell Products:"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 2255,
                                                                    columnNumber: 27
                                                                }, this),
                                                                " Displayed in the cart to suggest complementary items"
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                            lineNumber: 2255,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                            children: "• Select products that complement or enhance the main product"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                            lineNumber: 2256,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                    lineNumber: 2253,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                            lineNumber: 2251,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                    lineNumber: 2055,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TabsContent"], {
                                    value: "attributes",
                                    className: "space-y-2 mt-2",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "space-y-4",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex items-center justify-between",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                                className: "text-lg font-semibold text-white",
                                                                children: "Product Attributes"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                lineNumber: 2266,
                                                                columnNumber: 23
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                className: "text-sm text-slate-400",
                                                                children: "Add attributes like size, color, material to create product variations"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                lineNumber: 2267,
                                                                columnNumber: 23
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                        lineNumber: 2265,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                        onClick: addAttribute,
                                                        className: "px-4 py-2 bg-slate-800/50 border border-slate-700 rounded-lg text-slate-300 hover:bg-slate-800 transition-all text-sm flex items-center gap-2",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$tag$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tag$3e$__["Tag"], {
                                                                className: "h-4 w-4"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                lineNumber: 2275,
                                                                columnNumber: 23
                                                            }, this),
                                                            "Add Attribute"
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                        lineNumber: 2271,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                lineNumber: 2264,
                                                columnNumber: 19
                                            }, this),
                                            attributes.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "text-center py-12 border-2 border-dashed border-slate-700 rounded-xl bg-slate-800/20",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$package$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Package$3e$__["Package"], {
                                                        className: "mx-auto h-16 w-16 text-slate-600 mb-4"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                        lineNumber: 2282,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                        className: "text-lg font-semibold text-white mb-2",
                                                        children: "No Attributes Yet"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                        lineNumber: 2283,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "text-slate-400 mb-4",
                                                        children: 'Click "Add Attribute" to create product variations'
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                        lineNumber: 2284,
                                                        columnNumber: 23
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                lineNumber: 2281,
                                                columnNumber: 21
                                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "space-y-4",
                                                children: attributes.map((attribute, attrIdx)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "bg-slate-800/30 border border-slate-700 rounded-xl p-4",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "space-y-4",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: "flex items-start gap-4",
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                            className: "flex-1",
                                                                            children: [
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                                    className: "block text-sm font-medium text-slate-300 mb-2",
                                                                                    children: [
                                                                                        "Attribute Name ",
                                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                            className: "text-red-500",
                                                                                            children: "*"
                                                                                        }, void 0, false, {
                                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                                            lineNumber: 2296,
                                                                                            columnNumber: 50
                                                                                        }, this)
                                                                                    ]
                                                                                }, void 0, true, {
                                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                                    lineNumber: 2295,
                                                                                    columnNumber: 33
                                                                                }, this),
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                                    type: "text",
                                                                                    value: attribute.name,
                                                                                    onChange: (e)=>updateAttributeName(attribute.id, e.target.value),
                                                                                    placeholder: "e.g., Size, Color, Material",
                                                                                    className: "w-full px-3 py-2 bg-slate-800/50 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:ring-2 focus:ring-violet-500 focus:border-transparent transition-all"
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                                    lineNumber: 2298,
                                                                                    columnNumber: 33
                                                                                }, this)
                                                                            ]
                                                                        }, void 0, true, {
                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                            lineNumber: 2294,
                                                                            columnNumber: 31
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                            onClick: ()=>removeAttribute(attribute.id),
                                                                            className: "mt-7 p-2 bg-red-500/20 border border-red-500/30 text-red-400 hover:bg-red-500/30 rounded-lg transition-all",
                                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                                                                                className: "h-4 w-4"
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                                lineNumber: 2310,
                                                                                columnNumber: 33
                                                                            }, this)
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                            lineNumber: 2306,
                                                                            columnNumber: 31
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 2293,
                                                                    columnNumber: 29
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                            className: "block text-sm font-medium text-slate-300 mb-2",
                                                                            children: "Values"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                            lineNumber: 2315,
                                                                            columnNumber: 31
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                            className: "space-y-2",
                                                                            children: [
                                                                                attribute.values.map((value, valueIdx)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                        className: "flex items-center gap-2",
                                                                                        children: [
                                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                                                type: "text",
                                                                                                value: value,
                                                                                                onChange: (e)=>updateAttributeValue(attribute.id, valueIdx, e.target.value),
                                                                                                placeholder: "e.g., Small, Red, Cotton",
                                                                                                className: "flex-1 px-3 py-2 bg-slate-800/50 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:ring-2 focus:ring-violet-500 focus:border-transparent transition-all"
                                                                                            }, void 0, false, {
                                                                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                                                lineNumber: 2319,
                                                                                                columnNumber: 37
                                                                                            }, this),
                                                                                            attribute.values.length > 1 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                                                onClick: ()=>removeAttributeValue(attribute.id, valueIdx),
                                                                                                className: "p-2 bg-slate-800/50 border border-slate-700 text-slate-400 hover:text-red-400 hover:border-red-500/30 rounded-lg transition-all",
                                                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                                                                                                    className: "h-4 w-4"
                                                                                                }, void 0, false, {
                                                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                                                    lineNumber: 2331,
                                                                                                    columnNumber: 41
                                                                                                }, this)
                                                                                            }, void 0, false, {
                                                                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                                                lineNumber: 2327,
                                                                                                columnNumber: 39
                                                                                            }, this)
                                                                                        ]
                                                                                    }, valueIdx, true, {
                                                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                                        lineNumber: 2318,
                                                                                        columnNumber: 35
                                                                                    }, this)),
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                                    onClick: ()=>addAttributeValue(attribute.id),
                                                                                    className: "w-full px-4 py-2 bg-slate-800/50 border border-slate-700 rounded-lg text-slate-300 hover:bg-slate-800 transition-all text-sm",
                                                                                    children: "+ Add Value"
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                                    lineNumber: 2336,
                                                                                    columnNumber: 33
                                                                                }, this)
                                                                            ]
                                                                        }, void 0, true, {
                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                            lineNumber: 2316,
                                                                            columnNumber: 31
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 2314,
                                                                    columnNumber: 29
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                            lineNumber: 2292,
                                                            columnNumber: 27
                                                        }, this)
                                                    }, attribute.id, false, {
                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                        lineNumber: 2291,
                                                        columnNumber: 25
                                                    }, this))
                                            }, void 0, false, {
                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                lineNumber: 2289,
                                                columnNumber: 21
                                            }, this),
                                            formData.productType === 'grouped' && attributes.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "bg-violet-500/10 border border-violet-500/30 rounded-xl p-4",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                                        className: "font-semibold text-sm text-violet-400 mb-2",
                                                        children: "Product Variations"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                        lineNumber: 2353,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "text-sm text-slate-300",
                                                        children: [
                                                            "With the attributes you've added, you can create ",
                                                            attributes.reduce((acc, attr)=>acc * attr.values.filter((v)=>v).length, 1),
                                                            " product variations. Each variation will have its own price, SKU, and inventory."
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                        lineNumber: 2354,
                                                        columnNumber: 23
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                lineNumber: 2352,
                                                columnNumber: 21
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                        lineNumber: 2263,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                    lineNumber: 2262,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TabsContent"], {
                                    value: "seo",
                                    className: "space-y-2 mt-2",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "space-y-4",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                className: "text-lg font-semibold text-white border-b border-slate-800 pb-2",
                                                children: "Search Engine Optimization"
                                            }, void 0, false, {
                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                lineNumber: 2367,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-sm text-slate-400",
                                                children: "Optimize your product for search engines to improve visibility"
                                            }, void 0, false, {
                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                lineNumber: 2368,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                        className: "block text-sm font-medium text-slate-300 mb-2",
                                                        children: "Meta Title"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                        lineNumber: 2373,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                        type: "text",
                                                        name: "metaTitle",
                                                        value: formData.metaTitle,
                                                        onChange: handleChange,
                                                        placeholder: "SEO-optimized title for search engines",
                                                        className: "w-full px-3 py-2 bg-slate-800/50 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:ring-2 focus:ring-violet-500 focus:border-transparent transition-all"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                        lineNumber: 2374,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "text-xs text-slate-400 mt-1",
                                                        children: "Recommended: 50-60 characters"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                        lineNumber: 2382,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                lineNumber: 2372,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                        className: "block text-sm font-medium text-slate-300 mb-2",
                                                        children: "Meta Description"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                        lineNumber: 2386,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                                                        name: "metaDescription",
                                                        value: formData.metaDescription,
                                                        onChange: handleChange,
                                                        placeholder: "Brief description for search engine results",
                                                        rows: 4,
                                                        className: "w-full px-3 py-2 bg-slate-800/50 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:ring-2 focus:ring-violet-500 focus:border-transparent transition-all"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                        lineNumber: 2387,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "text-xs text-slate-400 mt-1",
                                                        children: "Recommended: 150-160 characters"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                        lineNumber: 2395,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                lineNumber: 2385,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                        className: "block text-sm font-medium text-slate-300 mb-2",
                                                        children: "Meta Keywords"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                        lineNumber: 2399,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                        type: "text",
                                                        name: "metaKeywords",
                                                        value: formData.metaKeywords,
                                                        onChange: handleChange,
                                                        placeholder: "keyword1, keyword2, keyword3",
                                                        className: "w-full px-3 py-2 bg-slate-800/50 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:ring-2 focus:ring-violet-500 focus:border-transparent transition-all"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                        lineNumber: 2400,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "text-xs text-slate-400 mt-1",
                                                        children: "Comma-separated keywords"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                        lineNumber: 2408,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                lineNumber: 2398,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                        className: "block text-sm font-medium text-slate-300 mb-2",
                                                        children: "Search Engine Friendly Page Name"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                        lineNumber: 2412,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                        type: "text",
                                                        name: "searchEngineFriendlyPageName",
                                                        value: formData.searchEngineFriendlyPageName,
                                                        onChange: handleChange,
                                                        placeholder: "product-url-slug",
                                                        className: "w-full px-3 py-2 bg-slate-800/50 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:ring-2 focus:ring-violet-500 focus:border-transparent transition-all"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                        lineNumber: 2413,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "text-xs text-slate-400 mt-1",
                                                        children: "Leave empty to auto-generate from product name"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                        lineNumber: 2421,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                lineNumber: 2411,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "bg-violet-500/10 border border-violet-500/30 rounded-xl p-4",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                                        className: "font-semibold text-sm text-violet-400 mb-2",
                                                        children: "SEO Tips"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                        lineNumber: 2425,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                                        className: "text-sm text-slate-300 space-y-1",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                                children: "• Use descriptive, keyword-rich titles and descriptions"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                lineNumber: 2427,
                                                                columnNumber: 23
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                                children: "• Keep meta titles under 60 characters"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                lineNumber: 2428,
                                                                columnNumber: 23
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                                children: "• Keep meta descriptions under 160 characters"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                lineNumber: 2429,
                                                                columnNumber: 23
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                                children: "• Use hyphens in URL slugs (e.g., wireless-headphones)"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                lineNumber: 2430,
                                                                columnNumber: 23
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                        lineNumber: 2426,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                lineNumber: 2424,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                        lineNumber: 2366,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                    lineNumber: 2365,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TabsContent"], {
                                    value: "pictures",
                                    className: "space-y-2 mt-2",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "space-y-4",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                className: "text-lg font-semibold text-white border-b border-slate-800 pb-2",
                                                children: "Product Images"
                                            }, void 0, false, {
                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                lineNumber: 2440,
                                                columnNumber: 5
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-sm text-slate-400",
                                                children: "Upload additional images or manage existing ones. Images are uploaded immediately."
                                            }, void 0, false, {
                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                lineNumber: 2441,
                                                columnNumber: 5
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "border-2 border-dashed rounded-xl p-8 bg-slate-800/20 transition-all ".concat(uploadingImages ? 'border-violet-500/50 bg-violet-500/5' : 'border-slate-700 hover:border-violet-500/50'),
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "text-center",
                                                    children: uploadingImages ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "space-y-4",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "w-16 h-16 border-4 border-violet-500 border-t-transparent rounded-full animate-spin mx-auto"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                lineNumber: 2454,
                                                                columnNumber: 13
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                                        className: "text-lg font-semibold text-white mb-2",
                                                                        children: "Uploading Images..."
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                        lineNumber: 2456,
                                                                        columnNumber: 15
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                        className: "text-sm text-slate-400",
                                                                        children: "Please wait while we upload your images"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                        lineNumber: 2457,
                                                                        columnNumber: 15
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                lineNumber: 2455,
                                                                columnNumber: 13
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                        lineNumber: 2453,
                                                        columnNumber: 11
                                                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$upload$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Upload$3e$__["Upload"], {
                                                                className: "mx-auto h-16 w-16 text-slate-500 mb-4"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                lineNumber: 2462,
                                                                columnNumber: 13
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                                className: "text-lg font-semibold text-white mb-2",
                                                                children: "Add More Images"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                lineNumber: 2463,
                                                                columnNumber: 13
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                className: "text-sm text-slate-400 mb-4",
                                                                children: !formData.name.trim() ? 'Please enter product name before uploading images' : 'Images will be uploaded immediately to the product'
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                lineNumber: 2464,
                                                                columnNumber: 13
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                ref: fileInputRef,
                                                                type: "file",
                                                                accept: "image/*",
                                                                multiple: true,
                                                                onChange: handleImageUpload,
                                                                disabled: !formData.name.trim() || uploadingImages,
                                                                className: "hidden"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                lineNumber: 2470,
                                                                columnNumber: 13
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                type: "button",
                                                                onClick: ()=>{
                                                                    var _fileInputRef_current;
                                                                    if (!formData.name.trim()) {
                                                                        toast.warning('Please enter product name first');
                                                                        return;
                                                                    }
                                                                    (_fileInputRef_current = fileInputRef.current) === null || _fileInputRef_current === void 0 ? void 0 : _fileInputRef_current.click();
                                                                },
                                                                disabled: uploadingImages,
                                                                className: "px-6 py-2.5 rounded-xl text-sm font-medium transition-all ".concat(!formData.name.trim() || uploadingImages ? 'bg-slate-700/50 text-slate-500 cursor-not-allowed' : 'bg-slate-800/50 border border-slate-700 text-slate-300 hover:bg-slate-800'),
                                                                children: uploadingImages ? 'Processing...' : 'Browse Files'
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                lineNumber: 2479,
                                                                columnNumber: 13
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                className: "text-xs text-slate-400 mt-3",
                                                                children: "Supported: JPG, PNG, WebP • Max 5MB each • Up to 10 images"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                lineNumber: 2497,
                                                                columnNumber: 13
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                        lineNumber: 2461,
                                                        columnNumber: 11
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                    lineNumber: 2451,
                                                    columnNumber: 7
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                lineNumber: 2446,
                                                columnNumber: 5
                                            }, this),
                                            formData.productImages.length > 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "space-y-4",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                                        className: "text-sm font-medium text-slate-300",
                                                        children: [
                                                            "Current Images (",
                                                            formData.productImages.length,
                                                            ")"
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                        lineNumber: 2508,
                                                        columnNumber: 9
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "grid grid-cols-2 md:grid-cols-3 gap-4",
                                                        children: formData.productImages.map((image, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "bg-slate-800/30 border border-slate-700 rounded-xl p-3 space-y-3 relative",
                                                                children: [
                                                                    image.isMain && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                        className: "absolute top-2 left-2 px-2 py-1 bg-violet-500 text-white text-xs font-medium rounded-lg z-10",
                                                                        children: "Main"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                        lineNumber: 2516,
                                                                        columnNumber: 17
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                        className: "aspect-square bg-slate-700/50 rounded-lg flex items-center justify-center overflow-hidden relative",
                                                                        children: [
                                                                            image.imageUrl ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                                                                src: image.imageUrl.startsWith('http') ? image.imageUrl : "".concat(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2d$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["API_BASE_URL"]).concat(image.imageUrl),
                                                                                alt: image.altText || 'Product image',
                                                                                className: "w-full h-full object-cover"
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                                lineNumber: 2523,
                                                                                columnNumber: 19
                                                                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Image$3e$__["Image"], {
                                                                                className: "h-12 w-12 text-slate-500"
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                                lineNumber: 2529,
                                                                                columnNumber: 19
                                                                            }, this),
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                                type: "button",
                                                                                onClick: ()=>removeImage(image.id),
                                                                                disabled: isDeletingImage,
                                                                                className: "absolute top-2 right-2 p-1.5 rounded-lg transition-all z-10 ".concat(isDeletingImage ? 'bg-slate-500/90 text-slate-300 cursor-not-allowed' : 'bg-red-500/90 text-white hover:bg-red-600'),
                                                                                title: isDeletingImage ? 'Deleting...' : 'Delete Image',
                                                                                children: isDeletingImage ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                    className: "w-3 h-3 border border-slate-300 border-t-transparent rounded-full animate-spin"
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                                    lineNumber: 2545,
                                                                                    columnNumber: 21
                                                                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                                                                                    className: "h-3 w-3"
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                                    lineNumber: 2547,
                                                                                    columnNumber: 21
                                                                                }, this)
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                                lineNumber: 2533,
                                                                                columnNumber: 17
                                                                            }, this)
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                        lineNumber: 2521,
                                                                        columnNumber: 15
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                        className: "space-y-2",
                                                                        children: [
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                                type: "text",
                                                                                placeholder: "Alt text",
                                                                                value: image.altText,
                                                                                onChange: (e)=>{
                                                                                    setFormData({
                                                                                        ...formData,
                                                                                        productImages: formData.productImages.map((img)=>img.id === image.id ? {
                                                                                                ...img,
                                                                                                altText: e.target.value
                                                                                            } : img)
                                                                                    });
                                                                                },
                                                                                className: "w-full px-2 py-1.5 text-xs bg-slate-800/50 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:ring-2 focus:ring-violet-500 focus:border-transparent transition-all"
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                                lineNumber: 2553,
                                                                                columnNumber: 17
                                                                            }, this),
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                className: "flex items-center gap-1",
                                                                                children: [
                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                                        type: "number",
                                                                                        placeholder: "Order",
                                                                                        value: image.sortOrder,
                                                                                        onChange: (e)=>{
                                                                                            setFormData({
                                                                                                ...formData,
                                                                                                productImages: formData.productImages.map((img)=>img.id === image.id ? {
                                                                                                        ...img,
                                                                                                        sortOrder: parseInt(e.target.value) || 1
                                                                                                    } : img)
                                                                                            });
                                                                                        },
                                                                                        className: "flex-1 px-2 py-1.5 text-xs bg-slate-800/50 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:ring-2 focus:ring-violet-500 focus:border-transparent transition-all"
                                                                                    }, void 0, false, {
                                                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                                        lineNumber: 2568,
                                                                                        columnNumber: 19
                                                                                    }, this),
                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                                        className: "flex items-center gap-1",
                                                                                        children: [
                                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                                                type: "checkbox",
                                                                                                checked: image.isMain,
                                                                                                onChange: (e)=>{
                                                                                                    setFormData({
                                                                                                        ...formData,
                                                                                                        productImages: formData.productImages.map((img)=>img.id === image.id ? {
                                                                                                                ...img,
                                                                                                                isMain: e.target.checked
                                                                                                            } : e.target.checked ? {
                                                                                                                ...img,
                                                                                                                isMain: false
                                                                                                            } : img)
                                                                                                    });
                                                                                                },
                                                                                                className: "w-3 h-3 text-violet-500"
                                                                                            }, void 0, false, {
                                                                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                                                lineNumber: 2583,
                                                                                                columnNumber: 21
                                                                                            }, this),
                                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                                className: "text-xs text-slate-400",
                                                                                                children: "Main"
                                                                                            }, void 0, false, {
                                                                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                                                lineNumber: 2597,
                                                                                                columnNumber: 21
                                                                                            }, this)
                                                                                        ]
                                                                                    }, void 0, true, {
                                                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                                        lineNumber: 2582,
                                                                                        columnNumber: 19
                                                                                    }, this)
                                                                                ]
                                                                            }, void 0, true, {
                                                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                                lineNumber: 2567,
                                                                                columnNumber: 17
                                                                            }, this),
                                                                            image.fileName && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                className: "text-xs text-slate-500",
                                                                                children: [
                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                        children: image.fileName
                                                                                    }, void 0, false, {
                                                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                                        lineNumber: 2604,
                                                                                        columnNumber: 21
                                                                                    }, this),
                                                                                    !image.file && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                        className: "text-xs text-green-400",
                                                                                        children: "✓ Saved"
                                                                                    }, void 0, false, {
                                                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                                        lineNumber: 2606,
                                                                                        columnNumber: 23
                                                                                    }, this)
                                                                                ]
                                                                            }, void 0, true, {
                                                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                                lineNumber: 2603,
                                                                                columnNumber: 19
                                                                            }, this)
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                        lineNumber: 2552,
                                                                        columnNumber: 15
                                                                    }, this)
                                                                ]
                                                            }, image.id, true, {
                                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                lineNumber: 2513,
                                                                columnNumber: 13
                                                            }, this))
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                        lineNumber: 2511,
                                                        columnNumber: 9
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                lineNumber: 2507,
                                                columnNumber: 7
                                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "text-center py-8 border border-slate-700 rounded-xl bg-slate-800/20",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Image$3e$__["Image"], {
                                                        className: "mx-auto h-12 w-12 text-slate-600 mb-2"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                        lineNumber: 2617,
                                                        columnNumber: 9
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "text-sm text-slate-400",
                                                        children: "No images uploaded yet"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                        lineNumber: 2618,
                                                        columnNumber: 9
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                lineNumber: 2616,
                                                columnNumber: 7
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "bg-violet-500/10 border border-violet-500/30 rounded-xl p-4",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                                        className: "font-semibold text-sm text-violet-400 mb-2",
                                                        children: "Edit Mode Information"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                        lineNumber: 2624,
                                                        columnNumber: 7
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                                        className: "text-sm text-slate-300 space-y-1",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                                children: "• Images are uploaded immediately to the product"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                lineNumber: 2626,
                                                                columnNumber: 9
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                                children: "• Delete images instantly using the delete button"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                lineNumber: 2627,
                                                                columnNumber: 9
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                                children: "• Changes to alt text and main image are saved when you update the product"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                lineNumber: 2628,
                                                                columnNumber: 9
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                                children: "• Supported formats: JPG, PNG, WebP (max 5MB each)"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                lineNumber: 2629,
                                                                columnNumber: 9
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                        lineNumber: 2625,
                                                        columnNumber: 7
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                lineNumber: 2623,
                                                columnNumber: 5
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                        lineNumber: 2439,
                                        columnNumber: 3
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                    lineNumber: 2438,
                                    columnNumber: 1
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TabsContent"], {
                                    value: "videos",
                                    className: "space-y-2 mt-2",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "space-y-4",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                className: "text-lg font-semibold text-white border-b border-slate-800 pb-2",
                                                children: "Product Videos"
                                            }, void 0, false, {
                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                lineNumber: 2638,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-sm text-slate-400",
                                                children: "Add video URLs (YouTube, Vimeo, etc.) to showcase your product"
                                            }, void 0, false, {
                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                lineNumber: 2639,
                                                columnNumber: 19
                                            }, this),
                                            formData.videoUrls.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "space-y-2",
                                                children: formData.videoUrls.map((url, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "flex items-center gap-2",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "flex-1 flex items-center gap-2 p-3 bg-slate-800/30 border border-slate-700 rounded-xl",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$video$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Video$3e$__["Video"], {
                                                                        className: "h-4 w-4 text-slate-400 flex-shrink-0"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                        lineNumber: 2649,
                                                                        columnNumber: 29
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                        type: "text",
                                                                        value: url,
                                                                        onChange: (e)=>{
                                                                            const newUrls = [
                                                                                ...formData.videoUrls
                                                                            ];
                                                                            newUrls[index] = e.target.value;
                                                                            setFormData({
                                                                                ...formData,
                                                                                videoUrls: newUrls
                                                                            });
                                                                        },
                                                                        placeholder: "https://youtube.com/watch?v=...",
                                                                        className: "flex-1 px-3 py-1.5 bg-slate-800/50 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:ring-2 focus:ring-violet-500 focus:border-transparent transition-all"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                        lineNumber: 2650,
                                                                        columnNumber: 29
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                lineNumber: 2648,
                                                                columnNumber: 27
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                onClick: ()=>{
                                                                    setFormData({
                                                                        ...formData,
                                                                        videoUrls: formData.videoUrls.filter((_, i)=>i !== index)
                                                                    });
                                                                },
                                                                className: "p-2.5 bg-red-500/20 border border-red-500/30 text-red-400 hover:bg-red-500/30 rounded-lg transition-all",
                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                                                                    className: "h-4 w-4"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 2671,
                                                                    columnNumber: 29
                                                                }, this)
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                lineNumber: 2662,
                                                                columnNumber: 27
                                                            }, this)
                                                        ]
                                                    }, index, true, {
                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                        lineNumber: 2647,
                                                        columnNumber: 25
                                                    }, this))
                                            }, void 0, false, {
                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                lineNumber: 2645,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                onClick: ()=>{
                                                    setFormData({
                                                        ...formData,
                                                        videoUrls: [
                                                            ...formData.videoUrls,
                                                            ''
                                                        ]
                                                    });
                                                },
                                                className: "w-full px-4 py-3 bg-slate-800/50 border border-slate-700 rounded-xl text-slate-300 hover:bg-slate-800 transition-all text-sm font-medium flex items-center justify-center gap-2",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$video$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Video$3e$__["Video"], {
                                                        className: "h-4 w-4"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                        lineNumber: 2688,
                                                        columnNumber: 21
                                                    }, this),
                                                    "Add Video URL"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                lineNumber: 2679,
                                                columnNumber: 19
                                            }, this),
                                            formData.videoUrls.length === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "text-center py-12 border-2 border-dashed border-slate-700 rounded-xl bg-slate-800/20",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$video$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Video$3e$__["Video"], {
                                                        className: "mx-auto h-16 w-16 text-slate-600 mb-4"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                        lineNumber: 2694,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                        className: "text-lg font-semibold text-white mb-2",
                                                        children: "No Videos Added"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                        lineNumber: 2695,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "text-slate-400 mb-4",
                                                        children: 'Click "Add Video URL" to embed product videos'
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                        lineNumber: 2696,
                                                        columnNumber: 23
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                lineNumber: 2693,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "bg-violet-500/10 border border-violet-500/30 rounded-xl p-4",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                                        className: "font-semibold text-sm text-violet-400 mb-2",
                                                        children: "Supported Video Platforms"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                        lineNumber: 2703,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                                        className: "text-sm text-slate-300 space-y-1",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                                children: "• YouTube (https://youtube.com/watch?v=...)"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                lineNumber: 2705,
                                                                columnNumber: 23
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                                children: "• Vimeo (https://vimeo.com/...)"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                lineNumber: 2706,
                                                                columnNumber: 23
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                                children: "• Direct video URLs (.mp4, .webm)"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                lineNumber: 2707,
                                                                columnNumber: 23
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                        lineNumber: 2704,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                lineNumber: 2702,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                        lineNumber: 2637,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                    lineNumber: 2636,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TabsContent"], {
                                    value: "specifications",
                                    className: "space-y-2 mt-2",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "space-y-4",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex items-center justify-between",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                                className: "text-lg font-semibold text-white",
                                                                children: "Product Specifications"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                lineNumber: 2718,
                                                                columnNumber: 23
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                className: "text-sm text-slate-400",
                                                                children: "Add technical specifications and product details"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                lineNumber: 2719,
                                                                columnNumber: 23
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                        lineNumber: 2717,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                        onClick: ()=>{
                                                            setFormData({
                                                                ...formData,
                                                                specifications: [
                                                                    ...formData.specifications,
                                                                    {
                                                                        id: Date.now().toString(),
                                                                        name: '',
                                                                        value: '',
                                                                        displayOrder: formData.specifications.length + 1
                                                                    }
                                                                ]
                                                            });
                                                        },
                                                        className: "px-4 py-2 bg-slate-800/50 border border-slate-700 rounded-lg text-slate-300 hover:bg-slate-800 transition-all text-sm flex items-center gap-2",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chart$2d$column$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BarChart3$3e$__["BarChart3"], {
                                                                className: "h-4 w-4"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                lineNumber: 2735,
                                                                columnNumber: 23
                                                            }, this),
                                                            "Add Specification"
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                        lineNumber: 2723,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                lineNumber: 2716,
                                                columnNumber: 19
                                            }, this),
                                            formData.specifications.length > 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "space-y-3",
                                                children: formData.specifications.map((spec)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "bg-slate-800/30 border border-slate-700 rounded-xl p-4",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "grid md:grid-cols-12 gap-3",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: "md:col-span-4",
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                            className: "block text-sm font-medium text-slate-300 mb-2",
                                                                            children: "Specification Name"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                            lineNumber: 2746,
                                                                            columnNumber: 31
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                            type: "text",
                                                                            value: spec.name,
                                                                            onChange: (e)=>{
                                                                                setFormData({
                                                                                    ...formData,
                                                                                    specifications: formData.specifications.map((s)=>s.id === spec.id ? {
                                                                                            ...s,
                                                                                            name: e.target.value
                                                                                        } : s)
                                                                                });
                                                                            },
                                                                            placeholder: "e.g., Processor, RAM, Storage",
                                                                            className: "w-full px-3 py-2 bg-slate-800/50 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:ring-2 focus:ring-violet-500 focus:border-transparent transition-all"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                            lineNumber: 2747,
                                                                            columnNumber: 31
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 2745,
                                                                    columnNumber: 29
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: "md:col-span-5",
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                            className: "block text-sm font-medium text-slate-300 mb-2",
                                                                            children: "Value"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                            lineNumber: 2763,
                                                                            columnNumber: 31
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                            type: "text",
                                                                            value: spec.value,
                                                                            onChange: (e)=>{
                                                                                setFormData({
                                                                                    ...formData,
                                                                                    specifications: formData.specifications.map((s)=>s.id === spec.id ? {
                                                                                            ...s,
                                                                                            value: e.target.value
                                                                                        } : s)
                                                                                });
                                                                            },
                                                                            placeholder: "e.g., Intel Core i7, 16GB, 512GB SSD",
                                                                            className: "w-full px-3 py-2 bg-slate-800/50 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:ring-2 focus:ring-violet-500 focus:border-transparent transition-all"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                            lineNumber: 2764,
                                                                            columnNumber: 31
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 2762,
                                                                    columnNumber: 29
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: "md:col-span-2",
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                            className: "block text-sm font-medium text-slate-300 mb-2",
                                                                            children: "Order"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                            lineNumber: 2780,
                                                                            columnNumber: 31
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                            type: "number",
                                                                            value: spec.displayOrder,
                                                                            onChange: (e)=>{
                                                                                setFormData({
                                                                                    ...formData,
                                                                                    specifications: formData.specifications.map((s)=>s.id === spec.id ? {
                                                                                            ...s,
                                                                                            displayOrder: parseInt(e.target.value) || 0
                                                                                        } : s)
                                                                                });
                                                                            },
                                                                            className: "w-full px-3 py-2 bg-slate-800/50 border border-slate-700 rounded-xl text-white focus:ring-2 focus:ring-violet-500 focus:border-transparent transition-all"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                            lineNumber: 2781,
                                                                            columnNumber: 31
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 2779,
                                                                    columnNumber: 29
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: "md:col-span-1 flex items-end",
                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                        onClick: ()=>{
                                                                            setFormData({
                                                                                ...formData,
                                                                                specifications: formData.specifications.filter((s)=>s.id !== spec.id)
                                                                            });
                                                                        },
                                                                        className: "w-full p-2 bg-red-500/20 border border-red-500/30 text-red-400 hover:bg-red-500/30 rounded-lg transition-all",
                                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                                                                            className: "h-4 w-4 mx-auto"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                            lineNumber: 2805,
                                                                            columnNumber: 33
                                                                        }, this)
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                        lineNumber: 2796,
                                                                        columnNumber: 31
                                                                    }, this)
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                    lineNumber: 2795,
                                                                    columnNumber: 29
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                            lineNumber: 2744,
                                                            columnNumber: 27
                                                        }, this)
                                                    }, spec.id, false, {
                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                        lineNumber: 2743,
                                                        columnNumber: 25
                                                    }, this))
                                            }, void 0, false, {
                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                lineNumber: 2741,
                                                columnNumber: 21
                                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "text-center py-12 border-2 border-dashed border-slate-700 rounded-xl bg-slate-800/20",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chart$2d$column$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BarChart3$3e$__["BarChart3"], {
                                                        className: "mx-auto h-16 w-16 text-slate-600 mb-4"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                        lineNumber: 2814,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                        className: "text-lg font-semibold text-white mb-2",
                                                        children: "No Specifications Added"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                        lineNumber: 2815,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "text-slate-400 mb-4",
                                                        children: 'Click "Add Specification" to add technical details'
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                        lineNumber: 2816,
                                                        columnNumber: 23
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                lineNumber: 2813,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "bg-violet-500/10 border border-violet-500/30 rounded-xl p-4",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                                        className: "font-semibold text-sm text-violet-400 mb-2",
                                                        children: "Specification Examples"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                        lineNumber: 2823,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                                        className: "text-sm text-slate-300 space-y-1",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                                children: [
                                                                    "• ",
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                                                        children: "Electronics:"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                        lineNumber: 2825,
                                                                        columnNumber: 29
                                                                    }, this),
                                                                    " Processor, RAM, Storage, Display Size, Battery"
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                lineNumber: 2825,
                                                                columnNumber: 23
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                                children: [
                                                                    "• ",
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                                                        children: "Clothing:"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                        lineNumber: 2826,
                                                                        columnNumber: 29
                                                                    }, this),
                                                                    " Material, Care Instructions, Country of Origin"
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                lineNumber: 2826,
                                                                columnNumber: 23
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                                children: [
                                                                    "• ",
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                                                        children: "Furniture:"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                        lineNumber: 2827,
                                                                        columnNumber: 29
                                                                    }, this),
                                                                    " Dimensions, Material, Weight Capacity, Assembly"
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                                lineNumber: 2827,
                                                                columnNumber: 23
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                        lineNumber: 2824,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                                lineNumber: 2822,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                        lineNumber: 2715,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                                    lineNumber: 2714,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                            lineNumber: 1112,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                        lineNumber: 1111,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                    lineNumber: 1110,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
                lineNumber: 1108,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/admin/products/edit/[id]/page.tsx",
        lineNumber: 1063,
        columnNumber: 5
    }, this);
}
_s(EditProductPage, "DXpE97+DNC8NdzK+RxLSYvgXRQM=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$CustomToast$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useToast"]
    ];
});
_c = EditProductPage;
var _c;
__turbopack_context__.k.register(_c, "EditProductPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=_5a99bdf0._.js.map